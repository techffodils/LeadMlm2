<?php


class Welcome_model extends CI_Model(){
	
	
}