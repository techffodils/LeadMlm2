<?php

/* admin/layout/page_right.twig */
class __TwigTemplate_1886376cf58b69c75605cb858bce38263d9849dbb4969d8ac8bb406c37fa8eb9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "
\t\t\t<!-- start: PAGESLIDE RIGHT -->
\t\t\t<div id=\"pageslide-right\" class=\"pageslide slide-fixed inner\">
\t\t\t\t<div class=\"right-wrapper\">
\t\t\t\t\t<ul class=\"nav nav-tabs nav-justified\" id=\"sidebar-tab\">
\t\t\t\t\t\t<li class=\"active\">
\t\t\t\t\t\t\t<a href=\"#users\" role=\"tab\" data-toggle=\"tab\"><i class=\"fa fa-users\"></i></a>
\t\t\t\t\t\t</li>
\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t<a href=\"#notifications\" role=\"tab\" data-toggle=\"tab\"><i class=\"fa fa-bookmark \"></i></a>
\t\t\t\t\t\t</li>
\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t<a href=\"#settings\" role=\"tab\" data-toggle=\"tab\"><i class=\"fa fa-gear\"></i></a>
\t\t\t\t\t\t</li>
\t\t\t\t\t</ul>
\t\t\t\t\t<div class=\"tab-content\">
\t\t\t\t\t\t<div class=\"tab-pane active\" id=\"users\">
\t\t\t\t\t\t\t<div class=\"users-list\">
\t\t\t\t\t\t\t\t<h5 class=\"sidebar-title\">On-line</h5>
\t\t\t\t\t\t\t\t<ul class=\"media-list\">
\t\t\t\t\t\t\t\t\t<li class=\"media\">
\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-circle status-online\"></i>
\t\t\t\t\t\t\t\t\t\t\t<img alt=\"...\" src=\"assets/images/avatar-2.jpg\" class=\"media-object\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"media-body\">
\t\t\t\t\t\t\t\t\t\t\t\t<h4 class=\"media-heading\">Nicole Bell</h4>
\t\t\t\t\t\t\t\t\t\t\t\t<span> Content Designer </span>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"media\">
\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"user-label\">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"label label-default\">3</span>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-circle status-online\"></i>
\t\t\t\t\t\t\t\t\t\t\t<img alt=\"...\" src=\"assets/images/avatar-3.jpg\" class=\"media-object\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"media-body\">
\t\t\t\t\t\t\t\t\t\t\t\t<h4 class=\"media-heading\">Steven Thompson</h4>
\t\t\t\t\t\t\t\t\t\t\t\t<span> Visual Designer </span>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"media\">
\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-circle status-online\"></i>
\t\t\t\t\t\t\t\t\t\t\t<img alt=\"...\" src=\"assets/images/avatar-4.jpg\" class=\"media-object\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"media-body\">
\t\t\t\t\t\t\t\t\t\t\t\t<h4 class=\"media-heading\">Ella Patterson</h4>
\t\t\t\t\t\t\t\t\t\t\t\t<span> Web Editor </span>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"media\">
\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-circle status-online\"></i>
\t\t\t\t\t\t\t\t\t\t\t<img alt=\"...\" src=\"assets/images/avatar-5.jpg\" class=\"media-object\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"media-body\">
\t\t\t\t\t\t\t\t\t\t\t\t<h4 class=\"media-heading\">Kenneth Ross</h4>
\t\t\t\t\t\t\t\t\t\t\t\t<span> Senior Designer </span>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t\t<h5 class=\"sidebar-title\">Off-line</h5>
\t\t\t\t\t\t\t\t<ul class=\"media-list\">
\t\t\t\t\t\t\t\t\t<li class=\"media\">
\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t<img alt=\"...\" src=\"assets/images/avatar-6.jpg\" class=\"media-object\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"media-body\">
\t\t\t\t\t\t\t\t\t\t\t\t<h4 class=\"media-heading\">Nicole Bell</h4>
\t\t\t\t\t\t\t\t\t\t\t\t<span> Content Designer </span>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"media\">
\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"user-label\">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"label label-default\">3</span>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<img alt=\"...\" src=\"assets/images/avatar-7.jpg\" class=\"media-object\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"media-body\">
\t\t\t\t\t\t\t\t\t\t\t\t<h4 class=\"media-heading\">Steven Thompson</h4>
\t\t\t\t\t\t\t\t\t\t\t\t<span> Visual Designer </span>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"media\">
\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t<img alt=\"...\" src=\"assets/images/avatar-8.jpg\" class=\"media-object\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"media-body\">
\t\t\t\t\t\t\t\t\t\t\t\t<h4 class=\"media-heading\">Ella Patterson</h4>
\t\t\t\t\t\t\t\t\t\t\t\t<span> Web Editor </span>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"media\">
\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t<img alt=\"...\" src=\"assets/images/avatar-9.jpg\" class=\"media-object\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"media-body\">
\t\t\t\t\t\t\t\t\t\t\t\t<h4 class=\"media-heading\">Kenneth Ross</h4>
\t\t\t\t\t\t\t\t\t\t\t\t<span> Senior Designer </span>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"media\">
\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t<img alt=\"...\" src=\"assets/images/avatar-10.jpg\" class=\"media-object\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"media-body\">
\t\t\t\t\t\t\t\t\t\t\t\t<h4 class=\"media-heading\">Ella Patterson</h4>
\t\t\t\t\t\t\t\t\t\t\t\t<span> Web Editor </span>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"media\">
\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t<img alt=\"...\" src=\"assets/images/avatar-5.jpg\" class=\"media-object\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"media-body\">
\t\t\t\t\t\t\t\t\t\t\t\t<h4 class=\"media-heading\">Kenneth Ross</h4>
\t\t\t\t\t\t\t\t\t\t\t\t<span> Senior Designer </span>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"user-chat\">
\t\t\t\t\t\t\t\t<div class=\"sidebar-content\">
\t\t\t\t\t\t\t\t\t<a class=\"sidebar-back\" href=\"#\"><i class=\"fa fa-chevron-circle-left\"></i> Back</a>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"user-chat-form sidebar-content\">
\t\t\t\t\t\t\t\t\t<div class=\"input-group\">
\t\t\t\t\t\t\t\t\t\t<input type=\"text\" placeholder=\"Type a message here...\" class=\"form-control\">
\t\t\t\t\t\t\t\t\t\t<div class=\"input-group-btn\">
\t\t\t\t\t\t\t\t\t\t\t<button class=\"btn btn-blue no-radius\" type=\"button\">
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-chevron-right\"></i>
\t\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<ol class=\"discussion sidebar-content\">
\t\t\t\t\t\t\t\t\t<li class=\"other\">
\t\t\t\t\t\t\t\t\t\t<div class=\"avatar\">
\t\t\t\t\t\t\t\t\t\t\t<img src=\"assets/images/avatar-4.jpg\" alt=\"\">
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"messages\">
\t\t\t\t\t\t\t\t\t\t\t<p>
\t\t\t\t\t\t\t\t\t\t\t\tLorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.
\t\t\t\t\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t\t\t\t\t<span class=\"time\"> 51 min </span>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"self\">
\t\t\t\t\t\t\t\t\t\t<div class=\"avatar\">
\t\t\t\t\t\t\t\t\t\t\t<img src=\"assets/images/avatar-1.jpg\" alt=\"\">
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"messages\">
\t\t\t\t\t\t\t\t\t\t\t<p>
\t\t\t\t\t\t\t\t\t\t\t\tLorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.
\t\t\t\t\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t\t\t\t\t<span class=\"time\"> 37 mins </span>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"other\">
\t\t\t\t\t\t\t\t\t\t<div class=\"avatar\">
\t\t\t\t\t\t\t\t\t\t\t<img src=\"assets/images/avatar-4.jpg\" alt=\"\">
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"messages\">
\t\t\t\t\t\t\t\t\t\t\t<p>
\t\t\t\t\t\t\t\t\t\t\t\tLorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.
\t\t\t\t\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t</ol>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"tab-pane\" id=\"notifications\">
\t\t\t\t\t\t\t<div class=\"notifications\">
\t\t\t\t\t\t\t\t<div class=\"pageslide-title\">
\t\t\t\t\t\t\t\t\tYou have 11 notifications
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<ul class=\"pageslide-list\">
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"javascript:void(0)\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"label label-primary\"><i class=\"fa fa-user\"></i></span> <span class=\"message\"> New user registration</span> <span class=\"time\"> 1 min</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"javascript:void(0)\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"label label-success\"><i class=\"fa fa-comment\"></i></span> <span class=\"message\"> New comment</span> <span class=\"time\"> 7 min</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"javascript:void(0)\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"label label-success\"><i class=\"fa fa-comment\"></i></span> <span class=\"message\"> New comment</span> <span class=\"time\"> 8 min</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"javascript:void(0)\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"label label-success\"><i class=\"fa fa-comment\"></i></span> <span class=\"message\"> New comment</span> <span class=\"time\"> 16 min</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"javascript:void(0)\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"label label-primary\"><i class=\"fa fa-user\"></i></span> <span class=\"message\"> New user registration</span> <span class=\"time\"> 36 min</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"javascript:void(0)\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"label label-warning\"><i class=\"fa fa-shopping-cart\"></i></span> <span class=\"message\"> 2 items sold</span> <span class=\"time\"> 1 hour</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"warning\">
\t\t\t\t\t\t\t\t\t\t<a href=\"javascript:void(0)\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"label label-danger\"><i class=\"fa fa-user\"></i></span> <span class=\"message\"> User deleted account</span> <span class=\"time\"> 2 hour</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t\t<div class=\"view-all\">
\t\t\t\t\t\t\t\t\t<a href=\"javascript:void(0)\">
\t\t\t\t\t\t\t\t\t\tSee all notifications <i class=\"fa fa-arrow-circle-o-right\"></i>
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"tab-pane\" id=\"settings\">
\t\t\t\t\t\t\t<h5 class=\"sidebar-title\">General Settings</h5>
\t\t\t\t\t\t\t<ul class=\"media-list\">
\t\t\t\t\t\t\t\t<li class=\"media\">
\t\t\t\t\t\t\t\t\t<div class=\"checkbox sidebar-content\">
\t\t\t\t\t\t\t\t\t\t<label>
\t\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" value=\"\" class=\"green\" checked=\"checked\">
\t\t\t\t\t\t\t\t\t\t\tEnable Notifications
\t\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li class=\"media\">
\t\t\t\t\t\t\t\t\t<div class=\"checkbox sidebar-content\">
\t\t\t\t\t\t\t\t\t\t<label>
\t\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" value=\"\" class=\"green\" checked=\"checked\">
\t\t\t\t\t\t\t\t\t\t\tShow your E-mail
\t\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li class=\"media\">
\t\t\t\t\t\t\t\t\t<div class=\"checkbox sidebar-content\">
\t\t\t\t\t\t\t\t\t\t<label>
\t\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" value=\"\" class=\"green\">
\t\t\t\t\t\t\t\t\t\t\tShow Offline Users
\t\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li class=\"media\">
\t\t\t\t\t\t\t\t\t<div class=\"checkbox sidebar-content\">
\t\t\t\t\t\t\t\t\t\t<label>
\t\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" value=\"\" class=\"green\" checked=\"checked\">
\t\t\t\t\t\t\t\t\t\t\tE-mail Alerts
\t\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li class=\"media\">
\t\t\t\t\t\t\t\t\t<div class=\"checkbox sidebar-content\">
\t\t\t\t\t\t\t\t\t\t<label>
\t\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" value=\"\" class=\"green\">
\t\t\t\t\t\t\t\t\t\t\tSMS Alerts
\t\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t<div class=\"sidebar-content\">
\t\t\t\t\t\t\t\t<button class=\"btn btn-success\">
\t\t\t\t\t\t\t\t\t<i class=\"icon-settings\"></i> Save Changes
\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"hidden-xs\" id=\"style_selector\">
\t\t\t\t\t\t<div id=\"style_selector_container\">
\t\t\t\t\t\t\t<div class=\"pageslide-title\">
\t\t\t\t\t\t\t\tStyle Selector
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"box-title\">
\t\t\t\t\t\t\t\tChoose Your Layout Style
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"input-box\">
\t\t\t\t\t\t\t\t<div class=\"input\">
\t\t\t\t\t\t\t\t\t<select name=\"layout\" class=\"form-control\">
\t\t\t\t\t\t\t\t\t\t<option value=\"default\">Wide</option><option value=\"boxed\">Boxed</option>
\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"box-title\">
\t\t\t\t\t\t\t\tChoose Your Header Style
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"input-box\">
\t\t\t\t\t\t\t\t<div class=\"input\">
\t\t\t\t\t\t\t\t\t<select name=\"header\" class=\"form-control\">
\t\t\t\t\t\t\t\t\t\t<option value=\"fixed\">Fixed</option><option value=\"default\">Default</option>
\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"box-title\">
\t\t\t\t\t\t\t\tChoose Your Sidebar Style
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"input-box\">
\t\t\t\t\t\t\t\t<div class=\"input\">
\t\t\t\t\t\t\t\t\t<select name=\"sidebar\" class=\"form-control\">
\t\t\t\t\t\t\t\t\t\t<option value=\"fixed\">Fixed</option><option value=\"default\">Default</option>
\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"box-title\">
\t\t\t\t\t\t\t\tChoose Your Footer Style
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"input-box\">
\t\t\t\t\t\t\t\t<div class=\"input\">
\t\t\t\t\t\t\t\t\t<select name=\"footer\" class=\"form-control\">
\t\t\t\t\t\t\t\t\t\t<option value=\"default\">Default</option><option value=\"fixed\">Fixed</option>
\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"box-title\">
\t\t\t\t\t\t\t\t10 Predefined Color Schemes
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"images icons-color\">
\t\t\t\t\t\t\t\t<a href=\"#\" id=\"default\"><img src=\"assets/images/color-1.png\" alt=\"\" class=\"active\"></a>
\t\t\t\t\t\t\t\t<a href=\"#\" id=\"style2\"><img src=\"assets/images/color-2.png\" alt=\"\"></a>
\t\t\t\t\t\t\t\t<a href=\"#\" id=\"style3\"><img src=\"assets/images/color-3.png\" alt=\"\"></a>
\t\t\t\t\t\t\t\t<a href=\"#\" id=\"style4\"><img src=\"assets/images/color-4.png\" alt=\"\"></a>
\t\t\t\t\t\t\t\t<a href=\"#\" id=\"style5\"><img src=\"assets/images/color-5.png\" alt=\"\"></a>
\t\t\t\t\t\t\t\t<a href=\"#\" id=\"style6\"><img src=\"assets/images/color-6.png\" alt=\"\"></a>
\t\t\t\t\t\t\t\t<a href=\"#\" id=\"style7\"><img src=\"assets/images/color-7.png\" alt=\"\"></a>
\t\t\t\t\t\t\t\t<a href=\"#\" id=\"style8\"><img src=\"assets/images/color-8.png\" alt=\"\"></a>
\t\t\t\t\t\t\t\t<a href=\"#\" id=\"style9\"><img src=\"assets/images/color-9.png\" alt=\"\"></a>
\t\t\t\t\t\t\t\t<a href=\"#\" id=\"style10\"><img src=\"assets/images/color-10.png\" alt=\"\"></a>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"box-title\">
\t\t\t\t\t\t\t\tBackgrounds for Boxed Version
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"images boxed-patterns\">
\t\t\t\t\t\t\t\t<a href=\"#\" id=\"bg_style_1\"><img src=\"assets/images/bg.png\" alt=\"\"></a>
\t\t\t\t\t\t\t\t<a href=\"#\" id=\"bg_style_2\"><img src=\"assets/images/bg_2.png\" alt=\"\"></a>
\t\t\t\t\t\t\t\t<a href=\"#\" id=\"bg_style_3\"><img src=\"assets/images/bg_3.png\" alt=\"\"></a>
\t\t\t\t\t\t\t\t<a href=\"#\" id=\"bg_style_4\"><img src=\"assets/images/bg_4.png\" alt=\"\"></a>
\t\t\t\t\t\t\t\t<a href=\"#\" id=\"bg_style_5\"><img src=\"assets/images/bg_5.png\" alt=\"\"></a>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"style-options\">
\t\t\t\t\t\t\t\t<a href=\"#\" class=\"clear_style\">
\t\t\t\t\t\t\t\t\tClear Styles
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t<a href=\"#\" class=\"save_style\">
\t\t\t\t\t\t\t\t\tSave Styles
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"style-toggle open\"></div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<!-- end: PAGESLIDE RIGHT -->";
    }

    public function getTemplateName()
    {
        return "admin/layout/page_right.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "admin/layout/page_right.twig", "C:\\xampp\\htdocs\\LeadMlm\\application\\views\\admin\\layout\\page_right.twig");
    }
}
