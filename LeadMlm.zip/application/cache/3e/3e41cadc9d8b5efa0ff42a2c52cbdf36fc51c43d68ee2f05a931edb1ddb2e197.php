<?php

/* auth/index.twig */
class __TwigTemplate_42ca4ae04338a01a6816f16a663f529ab15a951fdc949ab5237a17d129c9f687 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<!-- Template Name: Rapido - Responsive Admin Template build with Twitter Bootstrap 3.x Version: 1.2 Author: ClipTheme -->
<!--[if IE 8]><html class=\"ie8 no-js\" lang=\"en\"><![endif]-->
<!--[if IE 9]><html class=\"ie9 no-js\" lang=\"en\"><![endif]-->
<!--[if !IE]><!-->
<html lang=\"en\" class=\"no-js\">
\t<!--<![endif]-->
\t<!-- start: HEAD -->
\t<head>
\t\t<title>Rapido - Responsive Admin Template</title>
\t\t<!-- start: META -->
\t\t<meta charset=\"utf-8\" />
\t\t<!--[if IE]><meta http-equiv='X-UA-Compatible' content=\"IE=edge,IE=9,IE=8,chrome=1\" /><![endif]-->
\t\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0\">
\t\t<meta name=\"apple-mobile-web-app-capable\" content=\"yes\">
\t\t<meta name=\"apple-mobile-web-app-status-bar-style\" content=\"black\">
\t\t<meta content=\"\" name=\"description\" />
\t\t<meta content=\"\" name=\"author\" />
\t\t<base href=\"";
        // line 19
        echo twig_escape_filter($this->env, ($context["base_path"] ?? null), "html", null, true);
        echo "\" />
\t\t<!-- end: META -->
\t\t<!-- start: MAIN CSS -->
\t\t<link rel=\"stylesheet\" href=\"assets/plugins/bootstrap/css/bootstrap.min.css\">
\t\t<link rel=\"stylesheet\" href=\"assets/plugins/font-awesome/css/font-awesome.min.css\">
\t\t<link rel=\"stylesheet\" href=\"assets/plugins/animate.css/animate.min.css\">
\t\t<link rel=\"stylesheet\" href=\"assets/plugins/iCheck/skins/all.css\">
\t\t<link rel=\"stylesheet\" href=\"assets/css/styles.css\">
\t\t<link rel=\"stylesheet\" href=\"assets/css/styles-responsive.css\">
\t\t<link rel=\"stylesheet\" href=\"assets/plugins/iCheck/skins/all.css\">
\t\t<!--[if IE 7]>
\t\t<link rel=\"stylesheet\" href=\"assets/plugins/font-awesome/css/font-awesome-ie7.min.css\">
\t\t<![endif]-->
\t\t<!-- end: MAIN CSS -->
\t\t<!-- start: CSS REQUIRED FOR THIS PAGE ONLY -->
\t\t<!-- end: CSS REQUIRED FOR THIS PAGE ONLY -->
\t</head>
\t<!-- end: HEAD -->
\t<!-- start: BODY -->
\t<body class=\"login\">
\t\t<div class=\"row\">
\t\t\t<div class=\"main-login col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4\">
\t\t\t\t<div class=\"logo\">
\t\t\t\t\t<img src=\"assets/images/logo.png\">
\t\t\t\t</div>
\t\t\t\t<!-- start: LOGIN BOX -->
\t\t\t\t<div class=\"box-login\">
\t\t\t\t\t<h3>Sign in to your account</h3>
\t\t\t\t\t<p>
\t\t\t\t\t\tPlease enter your name and password to log in.
\t\t\t\t\t</p>
\t\t\t\t\t<form class=\"form-login\" action=\"auth/login\" method=\"post\">
\t\t\t\t\t\t<div class=\"errorHandler alert alert-danger no-display\">
\t\t\t\t\t\t\t<i class=\"fa fa-remove-sign\"></i> You have some form errors. Please check below.
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<fieldset>
\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t<span class=\"input-icon\">
\t\t\t\t\t\t\t\t\t<input type=\"text\" class=\"form-control\" name=\"username\" placeholder=\"Username\">
\t\t\t\t\t\t\t\t\t<i class=\"fa fa-user\"></i> </span>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"form-group form-actions\">
\t\t\t\t\t\t\t\t<span class=\"input-icon\">
\t\t\t\t\t\t\t\t\t<input type=\"password\" class=\"form-control password\" name=\"password\" placeholder=\"Password\">
\t\t\t\t\t\t\t\t\t<i class=\"fa fa-lock\"></i>
\t\t\t\t\t\t\t\t\t<a class=\"forgot\" href=\"#\">
\t\t\t\t\t\t\t\t\t\tI forgot my password
\t\t\t\t\t\t\t\t\t</a> </span>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"form-actions\">
\t\t\t\t\t\t\t\t<label for=\"remember\" class=\"checkbox-inline\">
\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" value='1' FALSE class=\"grey remember\" id=\"remember\" name=\"remember\">
\t\t\t\t\t\t\t\t\tKeep me signed in
\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t<button type=\"submit\" class=\"btn btn-green pull-right\">
\t\t\t\t\t\t\t\t\tLogin <i class=\"fa fa-arrow-circle-right\"></i>
\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"new-account\">
\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t<a href=\"#\" class=\"register\">
\t\t\t\t\t\t\t\t\tCreate an account
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</fieldset>
\t\t\t\t\t</form>
\t\t\t\t\t<!-- start: COPYRIGHT -->
\t\t\t\t\t<div class=\"copyright\">
\t\t\t\t\t\t2014 &copy; Rapido by cliptheme.
\t\t\t\t\t</div>
\t\t\t\t\t<!-- end: COPYRIGHT -->
\t\t\t\t</div>
\t\t\t\t<!-- end: LOGIN BOX -->
\t\t\t\t<!-- start: FORGOT BOX -->
\t\t\t\t<div class=\"box-forgot\">
\t\t\t\t\t<h3>Forget Password?</h3>
\t\t\t\t\t<p>
\t\t\t\t\t\tEnter your e-mail address below to reset your password.
\t\t\t\t\t</p>
\t\t\t\t\t<form class=\"form-forgot\">
\t\t\t\t\t\t<div class=\"errorHandler alert alert-danger no-display\">
\t\t\t\t\t\t\t<i class=\"fa fa-remove-sign\"></i> You have some form errors. Please check below.
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<fieldset>
\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t<span class=\"input-icon\">
\t\t\t\t\t\t\t\t\t<input type=\"email\" class=\"form-control\" name=\"email\" placeholder=\"Email\">
\t\t\t\t\t\t\t\t\t<i class=\"fa fa-envelope\"></i> </span>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"form-actions\">
\t\t\t\t\t\t\t\t<a class=\"btn btn-light-grey go-back\">
\t\t\t\t\t\t\t\t\t<i class=\"fa fa-chevron-circle-left\"></i> Log-In
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t<button type=\"submit\" class=\"btn btn-green pull-right\">
\t\t\t\t\t\t\t\t\tSubmit <i class=\"fa fa-arrow-circle-right\"></i>
\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</fieldset>
\t\t\t\t\t</form>
\t\t\t\t\t<!-- start: COPYRIGHT -->
\t\t\t\t\t<div class=\"copyright\">
\t\t\t\t\t\t2014 &copy; Rapido by cliptheme.
\t\t\t\t\t</div>
\t\t\t\t\t<!-- end: COPYRIGHT -->
\t\t\t\t</div>
\t\t\t\t<!-- end: FORGOT BOX -->
\t\t\t\t<!-- start: REGISTER BOX -->
\t\t\t\t<div class=\"box-register\">
\t\t\t\t\t<h3>Sign Up</h3>
\t\t\t\t\t<p>
\t\t\t\t\t\tEnter your personal details below:
\t\t\t\t\t</p>
\t\t\t\t\t<form class=\"form-register\">
\t\t\t\t\t\t<div class=\"errorHandler alert alert-danger no-display\">
\t\t\t\t\t\t\t<i class=\"fa fa-remove-sign\"></i> You have some form errors. Please check below.
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<fieldset>
\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t<input type=\"text\" class=\"form-control\" name=\"full_name\" placeholder=\"Full Name\">
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t<input type=\"text\" class=\"form-control\" name=\"address\" placeholder=\"Address\">
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t<input type=\"text\" class=\"form-control\" name=\"city\" placeholder=\"City\">
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t\t<label class=\"radio-inline\">
\t\t\t\t\t\t\t\t\t\t<input type=\"radio\" class=\"grey\" value=\"F\" name=\"gender\">
\t\t\t\t\t\t\t\t\t\tFemale
\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t<label class=\"radio-inline\">
\t\t\t\t\t\t\t\t\t\t<input type=\"radio\" class=\"grey\" value=\"M\" name=\"gender\">
\t\t\t\t\t\t\t\t\t\tMale
\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<p>
\t\t\t\t\t\t\t\tEnter your account details below:
\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t<span class=\"input-icon\">
\t\t\t\t\t\t\t\t\t<input type=\"email\" class=\"form-control\" name=\"email\" placeholder=\"Email\">
\t\t\t\t\t\t\t\t\t<i class=\"fa fa-envelope\"></i> </span>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t<span class=\"input-icon\">
\t\t\t\t\t\t\t\t\t<input type=\"password\" class=\"form-control\" id=\"password\" name=\"password\" placeholder=\"Password\">
\t\t\t\t\t\t\t\t\t<i class=\"fa fa-lock\"></i> </span>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t<span class=\"input-icon\">
\t\t\t\t\t\t\t\t\t<input type=\"password\" class=\"form-control\" name=\"password_again\" placeholder=\"Password Again\">
\t\t\t\t\t\t\t\t\t<i class=\"fa fa-lock\"></i> </span>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t\t<label for=\"agree\" class=\"checkbox-inline\">
\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" class=\"grey agree\" id=\"agree\" name=\"agree\">
\t\t\t\t\t\t\t\t\t\tI agree to the Terms of Service and Privacy Policy
\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"form-actions\">
\t\t\t\t\t\t\t\tAlready have an account?
\t\t\t\t\t\t\t\t<a href=\"#\" class=\"go-back\">
\t\t\t\t\t\t\t\t\tLog-in
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t<button type=\"submit\" class=\"btn btn-green pull-right\">
\t\t\t\t\t\t\t\t\tSubmit <i class=\"fa fa-arrow-circle-right\"></i>
\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</fieldset>
\t\t\t\t\t</form>
\t\t\t\t\t<!-- start: COPYRIGHT -->
\t\t\t\t\t<div class=\"copyright\">
\t\t\t\t\t\t2014 &copy; Rapido by cliptheme.
\t\t\t\t\t</div>
\t\t\t\t\t<!-- end: COPYRIGHT -->
\t\t\t\t</div>
\t\t\t\t<!-- end: REGISTER BOX -->
\t\t\t</div>
\t\t</div>
\t\t<!-- start: MAIN JAVASCRIPTS -->
\t\t<!--[if lt IE 9]>
\t\t<script src=\"assets/plugins/respond.min.js\"></script>
\t\t<script src=\"assets/plugins/excanvas.min.js\"></script>
\t\t<script type=\"text/javascript\" src=\"assets/plugins/jQuery/jquery-1.11.1.min.js\"></script>
\t\t<![endif]-->
\t\t<!--[if gte IE 9]><!-->
\t\t<script src=\"assets/plugins/jQuery/jquery-2.1.1.min.js\"></script>
\t\t<!--<![endif]-->
\t\t<script src=\"assets/plugins/jquery-ui/jquery-ui-1.10.2.custom.min.js\"></script>
\t\t<script src=\"assets/plugins/bootstrap/js/bootstrap.min.js\"></script>
\t\t<script src=\"assets/plugins/iCheck/jquery.icheck.min.js\"></script>
\t\t<script src=\"assets/plugins/jquery.transit/jquery.transit.js\"></script>
\t\t<script src=\"assets/plugins/TouchSwipe/jquery.touchSwipe.min.js\"></script>
\t\t<script src=\"assets/js/main.js\"></script>
\t\t<!-- end: MAIN JAVASCRIPTS -->
\t\t<!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
\t\t<script src=\"assets/plugins/jquery-validation/dist/jquery.validate.min.js\"></script>
\t\t<script src=\"assets/js/login.js\"></script>
\t\t<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
\t\t<script>
\t\t\tjQuery(document).ready(function() {
\t\t\t\tMain.init();
\t\t\t\tLogin.init();
\t\t\t});
\t\t</script>
\t</body>
\t<!-- end: BODY -->
</html>";
    }

    public function getTemplateName()
    {
        return "auth/index.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  39 => 19,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "auth/index.twig", "C:\\xampp\\htdocs\\LeadMlm\\application\\views\\auth\\index.twig");
    }
}
