<?php

/* admin/layout/header.twig */
class __TwigTemplate_9d40b04797da8367b39fde20cb34b441ffe4b4151c5229be31600566c44d05c5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<!-- Template Name: Rapido - Responsive Admin Template build with Twitter Bootstrap 3.x Version: 1.2 Author: ClipTheme -->
<!--[if IE 8]><html class=\"ie8\" lang=\"en\"><![endif]-->
<!--[if IE 9]><html class=\"ie9\" lang=\"en\"><![endif]-->
<!--[if !IE]><!-->
<html lang=\"en\">
\t<!--<![endif]-->
\t<!-- start: HEAD -->
\t<head>
\t\t<title>Rapido - Responsive Admin Template</title>
\t\t<!-- start: META -->
\t\t<meta charset=\"utf-8\" />
\t\t<base href=\"";
        // line 13
        echo twig_escape_filter($this->env, ($context["BASE_URL"] ?? null), "html", null, true);
        echo "\" />
\t\t<!--[if IE]><meta http-equiv='X-UA-Compatible' content=\"IE=edge,IE=9,IE=8,chrome=1\" /><![endif]-->
\t\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0\">
\t\t<meta name=\"apple-mobile-web-app-capable\" content=\"yes\">
\t\t<meta name=\"apple-mobile-web-app-status-bar-style\" content=\"black\">
\t\t<meta content=\"\" name=\"description\" />
\t\t<meta content=\"\" name=\"author\" />
\t\t<!-- end: META -->
\t\t<!-- start: MAIN CSS -->
\t\t<link href='http://fonts.googleapis.com/css?family=Raleway:400,300,500,600,700,200,100,800' rel='stylesheet' type='text/css'>
\t\t<link rel=\"stylesheet\" href=\"assets/plugins/bootstrap/css/bootstrap.min.css\">
\t\t<link rel=\"stylesheet\" href=\"assets/plugins/font-awesome/css/font-awesome.min.css\">
\t\t<link rel=\"stylesheet\" href=\"assets/plugins/iCheck/skins/all.css\">
\t\t<link rel=\"stylesheet\" href=\"assets/plugins/perfect-scrollbar/src/perfect-scrollbar.css\">
\t\t<link rel=\"stylesheet\" href=\"assets/plugins/animate.css/animate.min.css\">
\t\t<!-- end: MAIN CSS -->
\t\t<!-- start: CSS REQUIRED FOR SUBVIEW CONTENTS -->
\t\t<link rel=\"stylesheet\" href=\"assets/plugins/owl-carousel/owl-carousel/owl.carousel.css\">
\t\t<link rel=\"stylesheet\" href=\"assets/plugins/owl-carousel/owl-carousel/owl.theme.css\">
\t\t<link rel=\"stylesheet\" href=\"assets/plugins/owl-carousel/owl-carousel/owl.transitions.css\">
\t\t<link rel=\"stylesheet\" href=\"assets/plugins/summernote/dist/summernote.css\">
\t\t<link rel=\"stylesheet\" href=\"assets/plugins/fullcalendar/fullcalendar/fullcalendar.css\">
\t\t<link rel=\"stylesheet\" href=\"assets/plugins/toastr/toastr.min.css\">
\t\t<link rel=\"stylesheet\" href=\"assets/plugins/bootstrap-select/bootstrap-select.min.css\">
\t\t<link rel=\"stylesheet\" href=\"assets/plugins/bootstrap-switch/dist/css/bootstrap3/bootstrap-switch.min.css\">
\t\t<link rel=\"stylesheet\" href=\"assets/plugins/DataTables/media/css/DT_bootstrap.css\">
\t\t<link rel=\"stylesheet\" href=\"assets/plugins/bootstrap-fileupload/bootstrap-fileupload.min.css\">
\t\t<link rel=\"stylesheet\" href=\"assets/plugins/bootstrap-daterangepicker/daterangepicker-bs3.css\">
\t\t<!-- end: CSS REQUIRED FOR THIS SUBVIEW CONTENTS-->
\t\t<!-- start: CSS REQUIRED FOR THIS PAGE ONLY -->
\t\t<!-- end: CSS REQUIRED FOR THIS PAGE ONLY -->
\t\t<!-- start: CORE CSS -->
\t\t<link rel=\"stylesheet\" href=\"assets/css/styles.css\">
\t\t<link rel=\"stylesheet\" href=\"assets/css/styles-responsive.css\">
\t\t<link rel=\"stylesheet\" href=\"assets/css/plugins.css\">
\t\t<link rel=\"stylesheet\" href=\"assets/css/themes/theme-style8.css\" type=\"text/css\" id=\"skin_color\">
\t\t<link rel=\"stylesheet\" href=\"assets/css/print.css\" type=\"text/css\" media=\"print\"/>
\t\t<!-- end: CORE CSS -->
\t\t<link rel=\"shortcut icon\" href=\"favicon.ico\" />
\t</head>
\t<!-- end: HEAD -->
\t
\t
\t<!-- start: BODY -->
\t<body>
\t\t<!-- start: SLIDING BAR (SB) -->
\t\t<div id=\"slidingbar-area\">
\t\t\t<div id=\"slidingbar\">
\t\t\t\t<div class=\"row\">
\t\t\t\t\t<!-- start: SLIDING BAR FIRST COLUMN -->
\t\t\t\t\t<div class=\"col-md-4 col-sm-4\">
\t\t\t\t\t\t<h2>My Options</h2>
\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t<div class=\"col-xs-6 col-lg-3\">
\t\t\t\t\t\t\t\t<button class=\"btn btn-icon btn-block space10\">
\t\t\t\t\t\t\t\t\t<i class=\"fa fa-folder-open-o\"></i>
\t\t\t\t\t\t\t\t\tProjects <span class=\"badge badge-info partition-red\"> 4 </span>
\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-xs-6 col-lg-3\">
\t\t\t\t\t\t\t\t<button class=\"btn btn-icon btn-block space10\">
\t\t\t\t\t\t\t\t\t<i class=\"fa fa-envelope-o\"></i>
\t\t\t\t\t\t\t\t\tMessages <span class=\"badge badge-info partition-red\"> 23 </span>
\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-xs-6 col-lg-3\">
\t\t\t\t\t\t\t\t<button class=\"btn btn-icon btn-block space10\">
\t\t\t\t\t\t\t\t\t<i class=\"fa fa-calendar-o\"></i>
\t\t\t\t\t\t\t\t\tCalendar <span class=\"badge badge-info partition-blue\"> 5 </span>
\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-xs-6 col-lg-3\">
\t\t\t\t\t\t\t\t<button class=\"btn btn-icon btn-block space10\">
\t\t\t\t\t\t\t\t\t<i class=\"fa fa-bell-o\"></i>
\t\t\t\t\t\t\t\t\tNotifications <span class=\"badge badge-info partition-red\"> 9 </span>
\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<!-- end: SLIDING BAR FIRST COLUMN -->
\t\t\t\t\t<!-- start: SLIDING BAR SECOND COLUMN -->
\t\t\t\t\t<div class=\"col-md-4 col-sm-4\">
\t\t\t\t\t\t<h2>My Recent Works</h2>
\t\t\t\t\t\t<div class=\"blog-photo-stream margin-bottom-30\">
\t\t\t\t\t\t\t<ul class=\"list-unstyled\">
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"#\"><img alt=\"\" src=\"assets/images/image01_th.jpg\"></a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"#\"><img alt=\"\" src=\"assets/images/image02_th.jpg\"></a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"#\"><img alt=\"\" src=\"assets/images/image03_th.jpg\"></a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"#\"><img alt=\"\" src=\"assets/images/image04_th.jpg\"></a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"#\"><img alt=\"\" src=\"assets/images/image05_th.jpg\"></a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"#\"><img alt=\"\" src=\"assets/images/image06_th.jpg\"></a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"#\"><img alt=\"\" src=\"assets/images/image07_th.jpg\"></a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"#\"><img alt=\"\" src=\"assets/images/image08_th.jpg\"></a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"#\"><img alt=\"\" src=\"assets/images/image09_th.jpg\"></a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"#\"><img alt=\"\" src=\"assets/images/image10_th.jpg\"></a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<!-- end: SLIDING BAR SECOND COLUMN -->
\t\t\t\t\t<!-- start: SLIDING BAR THIRD COLUMN -->
\t\t\t\t\t<div class=\"col-md-4 col-sm-4\">
\t\t\t\t\t\t<h2>My Info</h2>
\t\t\t\t\t\t<address class=\"margin-bottom-40\">
\t\t\t\t\t\t\tPeter Clark
\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t12345 Street Name, City Name, United States
\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\tP: (641)-734-4763
\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\tEmail:
\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\tpeter.clark@example.com
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t</address>
\t\t\t\t\t\t<a class=\"btn btn-transparent-white\" href=\"#\">
\t\t\t\t\t\t\t<i class=\"fa fa-pencil\"></i> Edit
\t\t\t\t\t\t</a>
\t\t\t\t\t</div>
\t\t\t\t\t<!-- end: SLIDING BAR THIRD COLUMN -->
\t\t\t\t</div>
\t\t\t\t<div class=\"row\">
\t\t\t\t\t<!-- start: SLIDING BAR TOGGLE BUTTON -->
\t\t\t\t\t<div class=\"col-md-12 text-center\">
\t\t\t\t\t\t<a href=\"#\" class=\"sb_toggle\"><i class=\"fa fa-chevron-up\"></i></a>
\t\t\t\t\t</div>
\t\t\t\t\t<!-- end: SLIDING BAR TOGGLE BUTTON -->
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t\t<!-- end: SLIDING BAR -->
\t\t
\t\t\t\t<div class=\"main-wrapper\">";
    }

    public function getTemplateName()
    {
        return "admin/layout/header.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  33 => 13,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "admin/layout/header.twig", "C:\\xampp\\htdocs\\LeadMlm\\application\\views\\admin\\layout\\header.twig");
    }
}
