<?php

/* user/home/index.twig */
class __TwigTemplate_b08d7c9b74d6547ecbd6f4f6c55f925af7aae9c39d7ea247fa739992b4f4d9ab extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $this->loadTemplate("user/layout/header.twig", "user/home/index.twig", 1)->display($context);
        // line 2
        $this->loadTemplate("user/layout/top_bar.twig", "user/home/index.twig", 2)->display($context);
        // line 3
        $this->loadTemplate("user/layout/menu.twig", "user/home/index.twig", 3)->display($context);
        // line 4
        echo "
";
        // line 5
        $this->loadTemplate("user/layout/page_right.twig", "user/home/index.twig", 5)->display($context);
        // line 6
        $this->loadTemplate("user/layout/main_container.twig", "user/home/index.twig", 6)->display($context);
        // line 7
        echo "

";
        // line 9
        $this->loadTemplate("admin/layout/footer.twig", "user/home/index.twig", 9)->display($context);
    }

    public function getTemplateName()
    {
        return "user/home/index.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  36 => 9,  32 => 7,  30 => 6,  28 => 5,  25 => 4,  23 => 3,  21 => 2,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "user/home/index.twig", "C:\\xampp\\htdocs\\LeadMlm\\application\\views\\user\\home\\index.twig");
    }
}
