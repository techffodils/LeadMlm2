<?php

/* admin/layout/main_container.twig */
class __TwigTemplate_60598a2553ef40b5e7183d9f8b3fb1c32ae1695a4c637a939ca980ff6b8d86c1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "
\t\t\t<!-- start: MAIN CONTAINER -->
\t\t\t<div class=\"main-container inner\">
\t\t\t\t<!-- start: PAGE -->
\t\t\t\t<div class=\"main-content\">
\t\t\t\t\t<!-- start: PANEL CONFIGURATION MODAL FORM -->
\t\t\t\t\t<div class=\"modal fade\" id=\"panel-config\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
\t\t\t\t\t\t<div class=\"modal-dialog\">
\t\t\t\t\t\t\t<div class=\"modal-content\">
\t\t\t\t\t\t\t\t<div class=\"modal-header\">
\t\t\t\t\t\t\t\t\t<button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">
\t\t\t\t\t\t\t\t\t\t&times;
\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t<h4 class=\"modal-title\">Panel Configuration</h4>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"modal-body\">
\t\t\t\t\t\t\t\t\tHere will be a configuration form
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"modal-footer\">
\t\t\t\t\t\t\t\t\t<button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">
\t\t\t\t\t\t\t\t\t\tClose
\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t<button type=\"button\" class=\"btn btn-primary\">
\t\t\t\t\t\t\t\t\t\tSave changes
\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<!-- /.modal-content -->
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<!-- /.modal-dialog -->
\t\t\t\t\t</div>
\t\t\t\t\t<!-- /.modal -->
\t\t\t\t\t<!-- end: SPANEL CONFIGURATION MODAL FORM -->
\t\t\t\t\t<div class=\"container\">
\t\t\t\t\t\t<!-- start: PAGE HEADER -->
\t\t\t\t\t\t<!-- start: TOOLBAR -->
\t\t\t\t\t\t<div class=\"toolbar row\">
\t\t\t\t\t\t\t<div class=\"col-sm-6 hidden-xs\">
\t\t\t\t\t\t\t\t<div class=\"page-header\">
\t\t\t\t\t\t\t\t\t<h1>";
        // line 40
        echo twig_escape_filter($this->env, ($context["header"] ?? null), "html", null, true);
        echo "<small>subtitle here</small></h1>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-sm-6 col-xs-12\">
\t\t\t\t\t\t\t\t<a href=\"#\" class=\"back-subviews\">
\t\t\t\t\t\t\t\t\t<i class=\"fa fa-chevron-left\"></i> BACK
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t<a href=\"#\" class=\"close-subviews\">
\t\t\t\t\t\t\t\t\t<i class=\"fa fa-times\"></i> CLOSE
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t<div class=\"toolbar-tools pull-right\">
\t\t\t\t\t\t\t\t\t<!-- start: TOP NAVIGATION MENU -->
\t\t\t\t\t\t\t\t\t<ul class=\"nav navbar-right\">
\t\t\t\t\t\t\t\t\t\t<!-- start: TO-DO DROPDOWN -->
\t\t\t\t\t\t\t\t\t\t<li class=\"dropdown\">
\t\t\t\t\t\t\t\t\t\t\t<a data-toggle=\"dropdown\" data-hover=\"dropdown\" class=\"dropdown-toggle\" data-close-others=\"true\" href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-plus\"></i> SUBVIEW
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"tooltip-notification hide\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"tooltip-notification-arrow\"></div>
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"tooltip-notification-inner\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"semi-bold\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tHI THERE!
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"message\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tTry the Subview Live Experience
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t<ul class=\"dropdown-menu dropdown-light dropdown-subview\">
\t\t\t\t\t\t\t\t\t\t\t\t<li class=\"dropdown-header\">
\t\t\t\t\t\t\t\t\t\t\t\t\tNotes
\t\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"#newNote\" class=\"new-note\"><span class=\"fa-stack\"> <i class=\"fa fa-file-text-o fa-stack-1x fa-lg\"></i> <i class=\"fa fa-plus fa-stack-1x stack-right-bottom text-danger\"></i> </span> Add new note</a>
\t\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"#readNote\" class=\"read-all-notes\"><span class=\"fa-stack\"> <i class=\"fa fa-file-text-o fa-stack-1x fa-lg\"></i> <i class=\"fa fa-share fa-stack-1x stack-right-bottom text-danger\"></i> </span> Read all notes</a>
\t\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t\t<li class=\"dropdown-header\">
\t\t\t\t\t\t\t\t\t\t\t\t\tCalendar
\t\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"#newEvent\" class=\"new-event\"><span class=\"fa-stack\"> <i class=\"fa fa-calendar-o fa-stack-1x fa-lg\"></i> <i class=\"fa fa-plus fa-stack-1x stack-right-bottom text-danger\"></i> </span> Add new event</a>
\t\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"#showCalendar\" class=\"show-calendar\"><span class=\"fa-stack\"> <i class=\"fa fa-calendar-o fa-stack-1x fa-lg\"></i> <i class=\"fa fa-share fa-stack-1x stack-right-bottom text-danger\"></i> </span> Show calendar</a>
\t\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t\t<li class=\"dropdown-header\">
\t\t\t\t\t\t\t\t\t\t\t\t\tContributors
\t\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"#newContributor\" class=\"new-contributor\"><span class=\"fa-stack\"> <i class=\"fa fa-user fa-stack-1x fa-lg\"></i> <i class=\"fa fa-plus fa-stack-1x stack-right-bottom text-danger\"></i> </span> Add new contributor</a>
\t\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"#showContributors\" class=\"show-contributors\"><span class=\"fa-stack\"> <i class=\"fa fa-user fa-stack-1x fa-lg\"></i> <i class=\"fa fa-share fa-stack-1x stack-right-bottom text-danger\"></i> </span> Show all contributor</a>
\t\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t<li class=\"dropdown\">
\t\t\t\t\t\t\t\t\t\t\t<a data-toggle=\"dropdown\" data-hover=\"dropdown\" class=\"dropdown-toggle\" data-close-others=\"true\" href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"messages-count badge badge-default hide\">3</span> <i class=\"fa fa-envelope\"></i> MESSAGES
\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t<ul class=\"dropdown-menu dropdown-light dropdown-messages\">
\t\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"dropdown-header\"> You have 9 messages</span>
\t\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"drop-down-wrapper ps-container\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<ul>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<li class=\"unread\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"javascript:;\" class=\"unread\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"clearfix\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"thread-image\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<img src=\"./assets/images/avatar-2.jpg\" alt=\"\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"thread-content\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"author\">Nicole Bell</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"preview\">Duis mollis, est non commodo luctus, nisi erat porttitor ligula...</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"time\"> Just Now</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"javascript:;\" class=\"unread\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"clearfix\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"thread-image\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<img src=\"./assets/images/avatar-3.jpg\" alt=\"\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"thread-content\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"author\">Steven Thompson</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"preview\">Duis mollis, est non commodo luctus, nisi erat porttitor ligula...</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"time\">8 hrs</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"javascript:;\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"clearfix\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"thread-image\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<img src=\"./assets/images/avatar-5.jpg\" alt=\"\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"thread-content\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"author\">Kenneth Ross</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"preview\">Duis mollis, est non commodo luctus, nisi erat porttitor ligula...</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"time\">14 hrs</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t\t<li class=\"view-all\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"pages_messages.html\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\tSee All
\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t<li class=\"menu-search\">
\t\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-search\"></i> SEARCH
\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t<!-- start: SEARCH POPOVER -->
\t\t\t\t\t\t\t\t\t\t\t<div class=\"popover bottom search-box transition-all\">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"arrow\"></div>
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"popover-content\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<!-- start: SEARCH FORM -->
\t\t\t\t\t\t\t\t\t\t\t\t\t<form class=\"\" id=\"searchform\" action=\"#\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"input-group\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"text\" class=\"form-control\" placeholder=\"Search\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"input-group-btn\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<button class=\"btn btn-main-color btn-squared\" type=\"button\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-search\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</button> </span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t</form>
\t\t\t\t\t\t\t\t\t\t\t\t\t<!-- end: SEARCH FORM -->
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<!-- end: SEARCH POPOVER -->
\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t\t\t<!-- end: TOP NAVIGATION MENU -->
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<!-- end: TOOLBAR -->
\t\t\t\t\t\t<!-- end: PAGE HEADER -->
\t\t\t\t\t\t<!-- start: BREADCRUMB -->
\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t\t<ol class=\"breadcrumb\">
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\tDashboard
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"active\">
\t\t\t\t\t\t\t\t\t\tInvoice
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t</ol>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<!-- end: BREADCRUMB -->
\t\t\t\t\t\t
\t\t\t\t\t\t
\t\t\t\t\t\t<!-- start: MAIN CONTENT -->
\t\t\t\t\t\t
\t\t\t\t\t\t
\t\t\t\t\t\t
\t\t\t\t\t\t";
    }

    public function getTemplateName()
    {
        return "admin/layout/main_container.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 40,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "admin/layout/main_container.twig", "C:\\xampp\\htdocs\\LeadMlm\\application\\views\\admin\\layout\\main_container.twig");
    }
}
