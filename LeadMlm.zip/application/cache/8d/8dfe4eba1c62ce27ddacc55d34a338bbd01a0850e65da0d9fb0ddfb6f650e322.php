<?php

/* welcome_message.twig */
class __TwigTemplate_569c66c5031bf99d5f996ad1924f51e0048cdbb17e0018cca8409c290dd36267 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<!-- Template Name: Rapido - Responsive Admin Template build with Twitter Bootstrap 3.x Version: 1.2 Author: ClipTheme -->
<!--[if IE 8]><html class=\"ie8\" lang=\"en\"><![endif]-->
<!--[if IE 9]><html class=\"ie9\" lang=\"en\"><![endif]-->
<!--[if !IE]><!-->
<html lang=\"en\">
\t<!--<![endif]-->
\t<!-- start: HEAD -->
\t<head>
\t\t<title>Rapido - Responsive Admin Template</title>
\t\t<!-- start: META -->
\t\t<meta charset=\"utf-8\" />
\t\t<base href=\"";
        // line 13
        echo twig_escape_filter($this->env, ($context["base_path"] ?? null), "html", null, true);
        echo "\" />
\t\t<!--[if IE]><meta http-equiv='X-UA-Compatible' content=\"IE=edge,IE=9,IE=8,chrome=1\" /><![endif]-->
\t\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0\">
\t\t<meta name=\"apple-mobile-web-app-capable\" content=\"yes\">
\t\t<meta name=\"apple-mobile-web-app-status-bar-style\" content=\"black\">
\t\t<meta content=\"\" name=\"description\" />
\t\t<meta content=\"\" name=\"author\" />
\t\t<!-- end: META -->
\t\t<!-- start: MAIN CSS -->
\t\t<link href='http://fonts.googleapis.com/css?family=Raleway:400,300,500,600,700,200,100,800' rel='stylesheet' type='text/css'>
\t\t<link rel=\"stylesheet\" href=\"assets/plugins/bootstrap/css/bootstrap.min.css\">
\t\t<link rel=\"stylesheet\" href=\"assets/plugins/font-awesome/css/font-awesome.min.css\">
\t\t<link rel=\"stylesheet\" href=\"assets/plugins/iCheck/skins/all.css\">
\t\t<link rel=\"stylesheet\" href=\"assets/plugins/perfect-scrollbar/src/perfect-scrollbar.css\">
\t\t<link rel=\"stylesheet\" href=\"assets/plugins/animate.css/animate.min.css\">
\t\t<!-- end: MAIN CSS -->
\t\t<!-- start: CSS REQUIRED FOR SUBVIEW CONTENTS -->
\t\t<link rel=\"stylesheet\" href=\"assets/plugins/owl-carousel/owl-carousel/owl.carousel.css\">
\t\t<link rel=\"stylesheet\" href=\"assets/plugins/owl-carousel/owl-carousel/owl.theme.css\">
\t\t<link rel=\"stylesheet\" href=\"assets/plugins/owl-carousel/owl-carousel/owl.transitions.css\">
\t\t<link rel=\"stylesheet\" href=\"assets/plugins/summernote/dist/summernote.css\">
\t\t<link rel=\"stylesheet\" href=\"assets/plugins/fullcalendar/fullcalendar/fullcalendar.css\">
\t\t<link rel=\"stylesheet\" href=\"assets/plugins/toastr/toastr.min.css\">
\t\t<link rel=\"stylesheet\" href=\"assets/plugins/bootstrap-select/bootstrap-select.min.css\">
\t\t<link rel=\"stylesheet\" href=\"assets/plugins/bootstrap-switch/dist/css/bootstrap3/bootstrap-switch.min.css\">
\t\t<link rel=\"stylesheet\" href=\"assets/plugins/DataTables/media/css/DT_bootstrap.css\">
\t\t<link rel=\"stylesheet\" href=\"assets/plugins/bootstrap-fileupload/bootstrap-fileupload.min.css\">
\t\t<link rel=\"stylesheet\" href=\"assets/plugins/bootstrap-daterangepicker/daterangepicker-bs3.css\">
\t\t<!-- end: CSS REQUIRED FOR THIS SUBVIEW CONTENTS-->
\t\t<!-- start: CSS REQUIRED FOR THIS PAGE ONLY -->
\t\t<!-- end: CSS REQUIRED FOR THIS PAGE ONLY -->
\t\t<!-- start: CORE CSS -->
\t\t<link rel=\"stylesheet\" href=\"assets/css/styles.css\">
\t\t<link rel=\"stylesheet\" href=\"assets/css/styles-responsive.css\">
\t\t<link rel=\"stylesheet\" href=\"assets/css/plugins.css\">
\t\t<link rel=\"stylesheet\" href=\"assets/css/themes/theme-style8.css\" type=\"text/css\" id=\"skin_color\">
\t\t<link rel=\"stylesheet\" href=\"assets/css/print.css\" type=\"text/css\" media=\"print\"/>
\t\t<!-- end: CORE CSS -->
\t\t<link rel=\"shortcut icon\" href=\"favicon.ico\" />
\t</head>
\t<!-- end: HEAD -->
\t<!-- start: BODY -->
\t<body>
\t\t<!-- start: SLIDING BAR (SB) -->
\t\t<div id=\"slidingbar-area\">
\t\t\t<div id=\"slidingbar\">
\t\t\t\t<div class=\"row\">
\t\t\t\t\t<!-- start: SLIDING BAR FIRST COLUMN -->
\t\t\t\t\t<div class=\"col-md-4 col-sm-4\">
\t\t\t\t\t\t<h2>My Options</h2>
\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t<div class=\"col-xs-6 col-lg-3\">
\t\t\t\t\t\t\t\t<button class=\"btn btn-icon btn-block space10\">
\t\t\t\t\t\t\t\t\t<i class=\"fa fa-folder-open-o\"></i>
\t\t\t\t\t\t\t\t\tProjects <span class=\"badge badge-info partition-red\"> 4 </span>
\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-xs-6 col-lg-3\">
\t\t\t\t\t\t\t\t<button class=\"btn btn-icon btn-block space10\">
\t\t\t\t\t\t\t\t\t<i class=\"fa fa-envelope-o\"></i>
\t\t\t\t\t\t\t\t\tMessages <span class=\"badge badge-info partition-red\"> 23 </span>
\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-xs-6 col-lg-3\">
\t\t\t\t\t\t\t\t<button class=\"btn btn-icon btn-block space10\">
\t\t\t\t\t\t\t\t\t<i class=\"fa fa-calendar-o\"></i>
\t\t\t\t\t\t\t\t\tCalendar <span class=\"badge badge-info partition-blue\"> 5 </span>
\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-xs-6 col-lg-3\">
\t\t\t\t\t\t\t\t<button class=\"btn btn-icon btn-block space10\">
\t\t\t\t\t\t\t\t\t<i class=\"fa fa-bell-o\"></i>
\t\t\t\t\t\t\t\t\tNotifications <span class=\"badge badge-info partition-red\"> 9 </span>
\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<!-- end: SLIDING BAR FIRST COLUMN -->
\t\t\t\t\t<!-- start: SLIDING BAR SECOND COLUMN -->
\t\t\t\t\t<div class=\"col-md-4 col-sm-4\">
\t\t\t\t\t\t<h2>My Recent Works</h2>
\t\t\t\t\t\t<div class=\"blog-photo-stream margin-bottom-30\">
\t\t\t\t\t\t\t<ul class=\"list-unstyled\">
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"#\"><img alt=\"\" src=\"assets/images/image01_th.jpg\"></a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"#\"><img alt=\"\" src=\"assets/images/image02_th.jpg\"></a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"#\"><img alt=\"\" src=\"assets/images/image03_th.jpg\"></a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"#\"><img alt=\"\" src=\"assets/images/image04_th.jpg\"></a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"#\"><img alt=\"\" src=\"assets/images/image05_th.jpg\"></a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"#\"><img alt=\"\" src=\"assets/images/image06_th.jpg\"></a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"#\"><img alt=\"\" src=\"assets/images/image07_th.jpg\"></a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"#\"><img alt=\"\" src=\"assets/images/image08_th.jpg\"></a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"#\"><img alt=\"\" src=\"assets/images/image09_th.jpg\"></a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"#\"><img alt=\"\" src=\"assets/images/image10_th.jpg\"></a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<!-- end: SLIDING BAR SECOND COLUMN -->
\t\t\t\t\t<!-- start: SLIDING BAR THIRD COLUMN -->
\t\t\t\t\t<div class=\"col-md-4 col-sm-4\">
\t\t\t\t\t\t<h2>My Info</h2>
\t\t\t\t\t\t<address class=\"margin-bottom-40\">
\t\t\t\t\t\t\tPeter Clark
\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t12345 Street Name, City Name, United States
\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\tP: (641)-734-4763
\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\tEmail:
\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\tpeter.clark@example.com
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t</address>
\t\t\t\t\t\t<a class=\"btn btn-transparent-white\" href=\"#\">
\t\t\t\t\t\t\t<i class=\"fa fa-pencil\"></i> Edit
\t\t\t\t\t\t</a>
\t\t\t\t\t</div>
\t\t\t\t\t<!-- end: SLIDING BAR THIRD COLUMN -->
\t\t\t\t</div>
\t\t\t\t<div class=\"row\">
\t\t\t\t\t<!-- start: SLIDING BAR TOGGLE BUTTON -->
\t\t\t\t\t<div class=\"col-md-12 text-center\">
\t\t\t\t\t\t<a href=\"#\" class=\"sb_toggle\"><i class=\"fa fa-chevron-up\"></i></a>
\t\t\t\t\t</div>
\t\t\t\t\t<!-- end: SLIDING BAR TOGGLE BUTTON -->
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t\t<!-- end: SLIDING BAR -->
\t\t<div class=\"main-wrapper\">
\t\t\t<!-- start: TOPBAR -->
\t\t\t<header class=\"topbar navbar navbar-inverse navbar-fixed-top inner\">
\t\t\t\t<!-- start: TOPBAR CONTAINER -->
\t\t\t\t<div class=\"container\">
\t\t\t\t\t<div class=\"navbar-header\">
\t\t\t\t\t\t<a class=\"sb-toggle-left hidden-md hidden-lg\" href=\"#main-navbar\">
\t\t\t\t\t\t\t<i class=\"fa fa-bars\"></i>
\t\t\t\t\t\t</a>
\t\t\t\t\t\t<!-- start: LOGO -->
\t\t\t\t\t\t<a class=\"navbar-brand\" href=\"index.html\">
\t\t\t\t\t\t\t<img src=\"assets/images/logo.png\" alt=\"Rapido\"/>
\t\t\t\t\t\t</a>
\t\t\t\t\t\t<!-- end: LOGO -->
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"topbar-tools\">
\t\t\t\t\t\t<!-- start: TOP NAVIGATION MENU -->
\t\t\t\t\t\t<ul class=\"nav navbar-right\">
\t\t\t\t\t\t\t<!-- start: USER DROPDOWN -->
\t\t\t\t\t\t\t<li class=\"dropdown current-user\">
\t\t\t\t\t\t\t\t<a data-toggle=\"dropdown\" data-hover=\"dropdown\" class=\"dropdown-toggle\" data-close-others=\"true\" href=\"#\">
\t\t\t\t\t\t\t\t\t<img src=\"assets/images/avatar-1-small.jpg\" class=\"img-circle\" alt=\"\"> <span class=\"username hidden-xs\">Peter Clark</span> <i class=\"fa fa-caret-down \"></i>
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t<ul class=\"dropdown-menu dropdown-dark\">
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"pages_user_profile.html\">
\t\t\t\t\t\t\t\t\t\t\tMy Profile
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"pages_calendar.html\">
\t\t\t\t\t\t\t\t\t\t\tMy Calendar
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"pages_messages.html\">
\t\t\t\t\t\t\t\t\t\t\tMy Messages (3)
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"login_lock_screen.html\">
\t\t\t\t\t\t\t\t\t\t\tLock Screen
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"login_login.html\">
\t\t\t\t\t\t\t\t\t\t\tLog Out
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<!-- end: USER DROPDOWN -->
\t\t\t\t\t\t\t<li class=\"right-menu-toggle\">
\t\t\t\t\t\t\t\t<a href=\"#\" class=\"sb-toggle-right\">
\t\t\t\t\t\t\t\t\t<i class=\"fa fa-globe toggle-icon\"></i> <i class=\"fa fa-caret-right\"></i> <span class=\"notifications-count badge badge-default hide\"> 3</span>
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t</ul>
\t\t\t\t\t\t<!-- end: TOP NAVIGATION MENU -->
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<!-- end: TOPBAR CONTAINER -->
\t\t\t</header>
\t\t\t<!-- end: TOPBAR -->
\t\t\t<!-- start: PAGESLIDE LEFT -->
\t\t\t<a class=\"closedbar inner hidden-sm hidden-xs\" href=\"#\">
\t\t\t</a>
\t\t\t<nav id=\"pageslide-left\" class=\"pageslide inner\">
\t\t\t\t<div class=\"navbar-content\">
\t\t\t\t\t<!-- start: SIDEBAR -->
\t\t\t\t\t<div class=\"main-navigation left-wrapper transition-left\">
\t\t\t\t\t\t<div class=\"navigation-toggler hidden-sm hidden-xs\">
\t\t\t\t\t\t\t<a href=\"#main-navbar\" class=\"sb-toggle-left\">
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"user-profile border-top padding-horizontal-10 block\">
\t\t\t\t\t\t\t<div class=\"inline-block\">
\t\t\t\t\t\t\t\t<img src=\"assets/images/avatar-1.jpg\" alt=\"\">
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"inline-block\">
\t\t\t\t\t\t\t\t<h5 class=\"no-margin\"> Welcome </h5>
\t\t\t\t\t\t\t\t<h4 class=\"no-margin\"> Peter Clark </h4>
\t\t\t\t\t\t\t\t<a class=\"btn user-options sb_toggle\">
\t\t\t\t\t\t\t\t\t<i class=\"fa fa-cog\"></i>
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<!-- start: MAIN NAVIGATION MENU -->
\t\t\t\t\t\t<ul class=\"main-navigation-menu\">
\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t<a href=\"index.html\"><i class=\"fa fa-home\"></i> <span class=\"title\"> Dashboard </span><span class=\"label label-default pull-right \">LABEL</span> </a>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t<a href=\"javascript:void(0)\"><i class=\"fa fa-desktop\"></i> <span class=\"title\"> Layouts </span><i class=\"icon-arrow\"></i> </a>
\t\t\t\t\t\t\t\t<ul class=\"sub-menu\">
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"javascript:;\">
\t\t\t\t\t\t\t\t\t\t\tHorizontal Menu <i class=\"icon-arrow\"></i>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t<ul class=\"sub-menu\">
\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"layouts_horizontal_menu.html\">
\t\t\t\t\t\t\t\t\t\t\t\t\tHorizontal Menu
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"layouts_horizontal_menu_fixed.html\">
\t\t\t\t\t\t\t\t\t\t\t\t\tHorizontal Menu Fixed
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"layouts_horizontal_sidebar_menu.html\">
\t\t\t\t\t\t\t\t\t\t\t\t\tHorizontal &amp; Sidebar Menu
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"layouts_sidebar_closed.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\"> Sidebar Closed </span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"layouts_sidebar_not_fixed.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\"> Sidebar Not Fixed </span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"layouts_boxed_layout.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\"> Boxed Layout </span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"layouts_footer_fixed.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\"> Footer Fixed </span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"layouts_single_page.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\"> Single-Page Interface </span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t<a href=\"javascript:void(0)\"><i class=\"fa fa-cogs\"></i> <span class=\"title\"> UI Lab </span><i class=\"icon-arrow\"></i> </a>
\t\t\t\t\t\t\t\t<ul class=\"sub-menu\">
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"ui_elements.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\"> Elements </span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"ui_buttons.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\"> Buttons </span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"ui_icons.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\"> Icons </span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"ui_animations.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\"> CSS3 Animation </span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"ui_subview.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\"> Subview </span> <span class=\"label partition-blue pull-right \">HOT</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"ui_modals.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\"> Extended Modals </span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"ui_tabs_accordions.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\"> Tabs &amp; Accordions </span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"ui_panels.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\"> Panels </span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"ui_notifications.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\"> Notifications </span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"ui_sliders.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\"> Sliders </span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"ui_treeview.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\"> Treeview </span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"ui_nestable.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\"> Nestable List </span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"ui_typography.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\"> Typography </span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t<a href=\"javascript:void(0)\"><i class=\"fa fa-th-large\"></i> <span class=\"title\"> Tables </span><i class=\"icon-arrow\"></i> </a>
\t\t\t\t\t\t\t\t<ul class=\"sub-menu\">
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"table_basic.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\">Basic Tables</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"table_responsive.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\">Responsive Tables</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"table_data.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\">Advanced Data Tables</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"table_export.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\">Table Export</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t<a href=\"javascript:void(0)\"><i class=\"fa fa-pencil-square-o\"></i> <span class=\"title\"> Forms </span><i class=\"icon-arrow\"></i> </a>
\t\t\t\t\t\t\t\t<ul class=\"sub-menu\">
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"form_elements.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\">Form Elements</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"form_wizard.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\">Form Wizard</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"form_validation.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\">Form Validation</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"form_inline.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\">Inline Editor</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"form_x_editable.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\">Form X-editable</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"form_image_cropping.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\">Image Cropping</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"form_multiple_upload.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\">Multiple File Upload</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"form_dropzone.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\">Dropzone File Upload</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t<a href=\"javascript:void(0)\"><i class=\"fa fa-user\"></i> <span class=\"title\">Login</span><i class=\"icon-arrow\"></i> </a>
\t\t\t\t\t\t\t\t<ul class=\"sub-menu\">
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"login_login.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\"> Login Form </span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"login_login.html?box=register\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\"> Registration Form </span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"login_login.html?box=forgot\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\"> Forgot Password Form </span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"login_lock_screen.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\">Lock Screen</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li class=\"active open\">
\t\t\t\t\t\t\t\t<a href=\"javascript:void(0)\"><i class=\"fa fa-code\"></i> <span class=\"title\">Pages</span><i class=\"icon-arrow\"></i> </a>
\t\t\t\t\t\t\t\t<ul class=\"sub-menu\">
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"pages_user_profile.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\">User Profile</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"active\">
\t\t\t\t\t\t\t\t\t\t<a href=\"pages_invoice.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\">Invoice</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"pages_gallery.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\">Gallery</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"pages_timeline.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\">Timeline</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"pages_calendar.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\">Calendar</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"pages_messages.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\">Messages</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"pages_blank_page.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\">Blank Page</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t<a href=\"javascript:void(0)\"><i class=\"fa fa-cubes\"></i> <span class=\"title\">Utility</span><i class=\"icon-arrow\"></i> </a>
\t\t\t\t\t\t\t\t<ul class=\"sub-menu\">
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"utility_faq.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\">Faq</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"utility_search_result.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\">Search Results </span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"utility_404_example1.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\">Error 404 Example 1</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"utility_404_example2.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\">Error 404 Example 2</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"utility_404_example3.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\">Error 404 Example 3</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"utility_500_example1.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\">Error 500 Example 1</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"utility_500_example2.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\">Error 500 Example 2</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"utility_pricing_table.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\">Pricing Table</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"utility_coming_soon.html\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"title\">Cooming Soon</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t<a href=\"javascript:;\" class=\"active\">
\t\t\t\t\t\t\t\t\t<i class=\"fa fa-folder\"></i> <span class=\"title\"> 3 Level Menu </span> <i class=\"icon-arrow\"></i>
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t<ul class=\"sub-menu\">
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"javascript:;\">
\t\t\t\t\t\t\t\t\t\t\tItem 1 <i class=\"icon-arrow\"></i>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t<ul class=\"sub-menu\">
\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t\t\tSample Link 1
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t\t\tSample Link 2
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t\t\tSample Link 3
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"javascript:;\">
\t\t\t\t\t\t\t\t\t\t\tItem 1 <i class=\"icon-arrow\"></i>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t<ul class=\"sub-menu\">
\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t\t\tSample Link 1
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t\t\tSample Link 1
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t\t\tSample Link 1
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\tItem 3
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t<a href=\"javascript:;\">
\t\t\t\t\t\t\t\t\t<i class=\"fa fa-folder-open\"></i> <span class=\"title\"> 4 Level Menu </span><i class=\"icon-arrow\"></i> <span class=\"arrow \"></span>
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t<ul class=\"sub-menu\">
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"javascript:;\">
\t\t\t\t\t\t\t\t\t\t\tItem 1 <i class=\"icon-arrow\"></i>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t<ul class=\"sub-menu\">
\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"javascript:;\">
\t\t\t\t\t\t\t\t\t\t\t\t\tSample Link 1 <i class=\"icon-arrow\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t<ul class=\"sub-menu\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"#\"><i class=\"fa fa-times\"></i> Sample Link 1</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"#\"><i class=\"fa fa-pencil\"></i> Sample Link 1</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"#\"><i class=\"fa fa-edit\"></i> Sample Link 1</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t\t\tSample Link 1
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t\t\tSample Link 2
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t\t\tSample Link 3
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"javascript:;\">
\t\t\t\t\t\t\t\t\t\t\tItem 2 <i class=\"icon-arrow\"></i>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t<ul class=\"sub-menu\">
\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t\t\tSample Link 1
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t\t\tSample Link 1
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t\t\tSample Link 1
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\tItem 3
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t<a href=\"maps.html\"><i class=\"fa fa-map-marker\"></i> <span class=\"title\">Maps</span> </a>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t<a href=\"charts.html\"><i class=\"fa fa-bar-chart-o\"></i> <span class=\"title\">Charts</span> </a>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t</ul>
\t\t\t\t\t\t<!-- end: MAIN NAVIGATION MENU -->
\t\t\t\t\t</div>
\t\t\t\t\t<!-- end: SIDEBAR -->
\t\t\t\t</div>
\t\t\t\t<div class=\"slide-tools\">
\t\t\t\t\t<div class=\"col-xs-6 text-left no-padding\">
\t\t\t\t\t\t<a class=\"btn btn-sm status\" href=\"#\">
\t\t\t\t\t\t\tStatus <i class=\"fa fa-dot-circle-o text-green\"></i> <span>Online</span>
\t\t\t\t\t\t</a>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"col-xs-6 text-right no-padding\">
\t\t\t\t\t\t<a class=\"btn btn-sm log-out text-right\" href=\"login_login.html\">
\t\t\t\t\t\t\t<i class=\"fa fa-power-off\"></i> Log Out
\t\t\t\t\t\t</a>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</nav>
\t\t\t<!-- end: PAGESLIDE LEFT -->
\t\t\t<!-- start: PAGESLIDE RIGHT -->
\t\t\t<div id=\"pageslide-right\" class=\"pageslide slide-fixed inner\">
\t\t\t\t<div class=\"right-wrapper\">
\t\t\t\t\t<ul class=\"nav nav-tabs nav-justified\" id=\"sidebar-tab\">
\t\t\t\t\t\t<li class=\"active\">
\t\t\t\t\t\t\t<a href=\"#users\" role=\"tab\" data-toggle=\"tab\"><i class=\"fa fa-users\"></i></a>
\t\t\t\t\t\t</li>
\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t<a href=\"#notifications\" role=\"tab\" data-toggle=\"tab\"><i class=\"fa fa-bookmark \"></i></a>
\t\t\t\t\t\t</li>
\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t<a href=\"#settings\" role=\"tab\" data-toggle=\"tab\"><i class=\"fa fa-gear\"></i></a>
\t\t\t\t\t\t</li>
\t\t\t\t\t</ul>
\t\t\t\t\t<div class=\"tab-content\">
\t\t\t\t\t\t<div class=\"tab-pane active\" id=\"users\">
\t\t\t\t\t\t\t<div class=\"users-list\">
\t\t\t\t\t\t\t\t<h5 class=\"sidebar-title\">On-line</h5>
\t\t\t\t\t\t\t\t<ul class=\"media-list\">
\t\t\t\t\t\t\t\t\t<li class=\"media\">
\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-circle status-online\"></i>
\t\t\t\t\t\t\t\t\t\t\t<img alt=\"...\" src=\"assets/images/avatar-2.jpg\" class=\"media-object\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"media-body\">
\t\t\t\t\t\t\t\t\t\t\t\t<h4 class=\"media-heading\">Nicole Bell</h4>
\t\t\t\t\t\t\t\t\t\t\t\t<span> Content Designer </span>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"media\">
\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"user-label\">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"label label-default\">3</span>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-circle status-online\"></i>
\t\t\t\t\t\t\t\t\t\t\t<img alt=\"...\" src=\"assets/images/avatar-3.jpg\" class=\"media-object\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"media-body\">
\t\t\t\t\t\t\t\t\t\t\t\t<h4 class=\"media-heading\">Steven Thompson</h4>
\t\t\t\t\t\t\t\t\t\t\t\t<span> Visual Designer </span>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"media\">
\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-circle status-online\"></i>
\t\t\t\t\t\t\t\t\t\t\t<img alt=\"...\" src=\"assets/images/avatar-4.jpg\" class=\"media-object\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"media-body\">
\t\t\t\t\t\t\t\t\t\t\t\t<h4 class=\"media-heading\">Ella Patterson</h4>
\t\t\t\t\t\t\t\t\t\t\t\t<span> Web Editor </span>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"media\">
\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-circle status-online\"></i>
\t\t\t\t\t\t\t\t\t\t\t<img alt=\"...\" src=\"assets/images/avatar-5.jpg\" class=\"media-object\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"media-body\">
\t\t\t\t\t\t\t\t\t\t\t\t<h4 class=\"media-heading\">Kenneth Ross</h4>
\t\t\t\t\t\t\t\t\t\t\t\t<span> Senior Designer </span>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t\t<h5 class=\"sidebar-title\">Off-line</h5>
\t\t\t\t\t\t\t\t<ul class=\"media-list\">
\t\t\t\t\t\t\t\t\t<li class=\"media\">
\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t<img alt=\"...\" src=\"assets/images/avatar-6.jpg\" class=\"media-object\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"media-body\">
\t\t\t\t\t\t\t\t\t\t\t\t<h4 class=\"media-heading\">Nicole Bell</h4>
\t\t\t\t\t\t\t\t\t\t\t\t<span> Content Designer </span>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"media\">
\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"user-label\">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"label label-default\">3</span>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<img alt=\"...\" src=\"assets/images/avatar-7.jpg\" class=\"media-object\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"media-body\">
\t\t\t\t\t\t\t\t\t\t\t\t<h4 class=\"media-heading\">Steven Thompson</h4>
\t\t\t\t\t\t\t\t\t\t\t\t<span> Visual Designer </span>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"media\">
\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t<img alt=\"...\" src=\"assets/images/avatar-8.jpg\" class=\"media-object\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"media-body\">
\t\t\t\t\t\t\t\t\t\t\t\t<h4 class=\"media-heading\">Ella Patterson</h4>
\t\t\t\t\t\t\t\t\t\t\t\t<span> Web Editor </span>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"media\">
\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t<img alt=\"...\" src=\"assets/images/avatar-9.jpg\" class=\"media-object\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"media-body\">
\t\t\t\t\t\t\t\t\t\t\t\t<h4 class=\"media-heading\">Kenneth Ross</h4>
\t\t\t\t\t\t\t\t\t\t\t\t<span> Senior Designer </span>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"media\">
\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t<img alt=\"...\" src=\"assets/images/avatar-10.jpg\" class=\"media-object\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"media-body\">
\t\t\t\t\t\t\t\t\t\t\t\t<h4 class=\"media-heading\">Ella Patterson</h4>
\t\t\t\t\t\t\t\t\t\t\t\t<span> Web Editor </span>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"media\">
\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t<img alt=\"...\" src=\"assets/images/avatar-5.jpg\" class=\"media-object\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"media-body\">
\t\t\t\t\t\t\t\t\t\t\t\t<h4 class=\"media-heading\">Kenneth Ross</h4>
\t\t\t\t\t\t\t\t\t\t\t\t<span> Senior Designer </span>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"user-chat\">
\t\t\t\t\t\t\t\t<div class=\"sidebar-content\">
\t\t\t\t\t\t\t\t\t<a class=\"sidebar-back\" href=\"#\"><i class=\"fa fa-chevron-circle-left\"></i> Back</a>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"user-chat-form sidebar-content\">
\t\t\t\t\t\t\t\t\t<div class=\"input-group\">
\t\t\t\t\t\t\t\t\t\t<input type=\"text\" placeholder=\"Type a message here...\" class=\"form-control\">
\t\t\t\t\t\t\t\t\t\t<div class=\"input-group-btn\">
\t\t\t\t\t\t\t\t\t\t\t<button class=\"btn btn-blue no-radius\" type=\"button\">
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-chevron-right\"></i>
\t\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<ol class=\"discussion sidebar-content\">
\t\t\t\t\t\t\t\t\t<li class=\"other\">
\t\t\t\t\t\t\t\t\t\t<div class=\"avatar\">
\t\t\t\t\t\t\t\t\t\t\t<img src=\"assets/images/avatar-4.jpg\" alt=\"\">
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"messages\">
\t\t\t\t\t\t\t\t\t\t\t<p>
\t\t\t\t\t\t\t\t\t\t\t\tLorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.
\t\t\t\t\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t\t\t\t\t<span class=\"time\"> 51 min </span>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"self\">
\t\t\t\t\t\t\t\t\t\t<div class=\"avatar\">
\t\t\t\t\t\t\t\t\t\t\t<img src=\"assets/images/avatar-1.jpg\" alt=\"\">
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"messages\">
\t\t\t\t\t\t\t\t\t\t\t<p>
\t\t\t\t\t\t\t\t\t\t\t\tLorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.
\t\t\t\t\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t\t\t\t\t<span class=\"time\"> 37 mins </span>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"other\">
\t\t\t\t\t\t\t\t\t\t<div class=\"avatar\">
\t\t\t\t\t\t\t\t\t\t\t<img src=\"assets/images/avatar-4.jpg\" alt=\"\">
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"messages\">
\t\t\t\t\t\t\t\t\t\t\t<p>
\t\t\t\t\t\t\t\t\t\t\t\tLorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.
\t\t\t\t\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t</ol>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"tab-pane\" id=\"notifications\">
\t\t\t\t\t\t\t<div class=\"notifications\">
\t\t\t\t\t\t\t\t<div class=\"pageslide-title\">
\t\t\t\t\t\t\t\t\tYou have 11 notifications
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<ul class=\"pageslide-list\">
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"javascript:void(0)\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"label label-primary\"><i class=\"fa fa-user\"></i></span> <span class=\"message\"> New user registration</span> <span class=\"time\"> 1 min</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"javascript:void(0)\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"label label-success\"><i class=\"fa fa-comment\"></i></span> <span class=\"message\"> New comment</span> <span class=\"time\"> 7 min</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"javascript:void(0)\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"label label-success\"><i class=\"fa fa-comment\"></i></span> <span class=\"message\"> New comment</span> <span class=\"time\"> 8 min</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"javascript:void(0)\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"label label-success\"><i class=\"fa fa-comment\"></i></span> <span class=\"message\"> New comment</span> <span class=\"time\"> 16 min</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"javascript:void(0)\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"label label-primary\"><i class=\"fa fa-user\"></i></span> <span class=\"message\"> New user registration</span> <span class=\"time\"> 36 min</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"javascript:void(0)\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"label label-warning\"><i class=\"fa fa-shopping-cart\"></i></span> <span class=\"message\"> 2 items sold</span> <span class=\"time\"> 1 hour</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"warning\">
\t\t\t\t\t\t\t\t\t\t<a href=\"javascript:void(0)\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"label label-danger\"><i class=\"fa fa-user\"></i></span> <span class=\"message\"> User deleted account</span> <span class=\"time\"> 2 hour</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t\t<div class=\"view-all\">
\t\t\t\t\t\t\t\t\t<a href=\"javascript:void(0)\">
\t\t\t\t\t\t\t\t\t\tSee all notifications <i class=\"fa fa-arrow-circle-o-right\"></i>
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"tab-pane\" id=\"settings\">
\t\t\t\t\t\t\t<h5 class=\"sidebar-title\">General Settings</h5>
\t\t\t\t\t\t\t<ul class=\"media-list\">
\t\t\t\t\t\t\t\t<li class=\"media\">
\t\t\t\t\t\t\t\t\t<div class=\"checkbox sidebar-content\">
\t\t\t\t\t\t\t\t\t\t<label>
\t\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" value=\"\" class=\"green\" checked=\"checked\">
\t\t\t\t\t\t\t\t\t\t\tEnable Notifications
\t\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li class=\"media\">
\t\t\t\t\t\t\t\t\t<div class=\"checkbox sidebar-content\">
\t\t\t\t\t\t\t\t\t\t<label>
\t\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" value=\"\" class=\"green\" checked=\"checked\">
\t\t\t\t\t\t\t\t\t\t\tShow your E-mail
\t\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li class=\"media\">
\t\t\t\t\t\t\t\t\t<div class=\"checkbox sidebar-content\">
\t\t\t\t\t\t\t\t\t\t<label>
\t\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" value=\"\" class=\"green\">
\t\t\t\t\t\t\t\t\t\t\tShow Offline Users
\t\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li class=\"media\">
\t\t\t\t\t\t\t\t\t<div class=\"checkbox sidebar-content\">
\t\t\t\t\t\t\t\t\t\t<label>
\t\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" value=\"\" class=\"green\" checked=\"checked\">
\t\t\t\t\t\t\t\t\t\t\tE-mail Alerts
\t\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li class=\"media\">
\t\t\t\t\t\t\t\t\t<div class=\"checkbox sidebar-content\">
\t\t\t\t\t\t\t\t\t\t<label>
\t\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" value=\"\" class=\"green\">
\t\t\t\t\t\t\t\t\t\t\tSMS Alerts
\t\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t<div class=\"sidebar-content\">
\t\t\t\t\t\t\t\t<button class=\"btn btn-success\">
\t\t\t\t\t\t\t\t\t<i class=\"icon-settings\"></i> Save Changes
\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"hidden-xs\" id=\"style_selector\">
\t\t\t\t\t\t<div id=\"style_selector_container\">
\t\t\t\t\t\t\t<div class=\"pageslide-title\">
\t\t\t\t\t\t\t\tStyle Selector
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"box-title\">
\t\t\t\t\t\t\t\tChoose Your Layout Style
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"input-box\">
\t\t\t\t\t\t\t\t<div class=\"input\">
\t\t\t\t\t\t\t\t\t<select name=\"layout\" class=\"form-control\">
\t\t\t\t\t\t\t\t\t\t<option value=\"default\">Wide</option><option value=\"boxed\">Boxed</option>
\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"box-title\">
\t\t\t\t\t\t\t\tChoose Your Header Style
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"input-box\">
\t\t\t\t\t\t\t\t<div class=\"input\">
\t\t\t\t\t\t\t\t\t<select name=\"header\" class=\"form-control\">
\t\t\t\t\t\t\t\t\t\t<option value=\"fixed\">Fixed</option><option value=\"default\">Default</option>
\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"box-title\">
\t\t\t\t\t\t\t\tChoose Your Sidebar Style
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"input-box\">
\t\t\t\t\t\t\t\t<div class=\"input\">
\t\t\t\t\t\t\t\t\t<select name=\"sidebar\" class=\"form-control\">
\t\t\t\t\t\t\t\t\t\t<option value=\"fixed\">Fixed</option><option value=\"default\">Default</option>
\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"box-title\">
\t\t\t\t\t\t\t\tChoose Your Footer Style
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"input-box\">
\t\t\t\t\t\t\t\t<div class=\"input\">
\t\t\t\t\t\t\t\t\t<select name=\"footer\" class=\"form-control\">
\t\t\t\t\t\t\t\t\t\t<option value=\"default\">Default</option><option value=\"fixed\">Fixed</option>
\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"box-title\">
\t\t\t\t\t\t\t\t10 Predefined Color Schemes
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"images icons-color\">
\t\t\t\t\t\t\t\t<a href=\"#\" id=\"default\"><img src=\"assets/images/color-1.png\" alt=\"\" class=\"active\"></a>
\t\t\t\t\t\t\t\t<a href=\"#\" id=\"style2\"><img src=\"assets/images/color-2.png\" alt=\"\"></a>
\t\t\t\t\t\t\t\t<a href=\"#\" id=\"style3\"><img src=\"assets/images/color-3.png\" alt=\"\"></a>
\t\t\t\t\t\t\t\t<a href=\"#\" id=\"style4\"><img src=\"assets/images/color-4.png\" alt=\"\"></a>
\t\t\t\t\t\t\t\t<a href=\"#\" id=\"style5\"><img src=\"assets/images/color-5.png\" alt=\"\"></a>
\t\t\t\t\t\t\t\t<a href=\"#\" id=\"style6\"><img src=\"assets/images/color-6.png\" alt=\"\"></a>
\t\t\t\t\t\t\t\t<a href=\"#\" id=\"style7\"><img src=\"assets/images/color-7.png\" alt=\"\"></a>
\t\t\t\t\t\t\t\t<a href=\"#\" id=\"style8\"><img src=\"assets/images/color-8.png\" alt=\"\"></a>
\t\t\t\t\t\t\t\t<a href=\"#\" id=\"style9\"><img src=\"assets/images/color-9.png\" alt=\"\"></a>
\t\t\t\t\t\t\t\t<a href=\"#\" id=\"style10\"><img src=\"assets/images/color-10.png\" alt=\"\"></a>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"box-title\">
\t\t\t\t\t\t\t\tBackgrounds for Boxed Version
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"images boxed-patterns\">
\t\t\t\t\t\t\t\t<a href=\"#\" id=\"bg_style_1\"><img src=\"assets/images/bg.png\" alt=\"\"></a>
\t\t\t\t\t\t\t\t<a href=\"#\" id=\"bg_style_2\"><img src=\"assets/images/bg_2.png\" alt=\"\"></a>
\t\t\t\t\t\t\t\t<a href=\"#\" id=\"bg_style_3\"><img src=\"assets/images/bg_3.png\" alt=\"\"></a>
\t\t\t\t\t\t\t\t<a href=\"#\" id=\"bg_style_4\"><img src=\"assets/images/bg_4.png\" alt=\"\"></a>
\t\t\t\t\t\t\t\t<a href=\"#\" id=\"bg_style_5\"><img src=\"assets/images/bg_5.png\" alt=\"\"></a>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"style-options\">
\t\t\t\t\t\t\t\t<a href=\"#\" class=\"clear_style\">
\t\t\t\t\t\t\t\t\tClear Styles
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t<a href=\"#\" class=\"save_style\">
\t\t\t\t\t\t\t\t\tSave Styles
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"style-toggle open\"></div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<!-- end: PAGESLIDE RIGHT -->
\t\t\t<!-- start: MAIN CONTAINER -->
\t\t\t<div class=\"main-container inner\">
\t\t\t\t<!-- start: PAGE -->
\t\t\t\t<div class=\"main-content\">
\t\t\t\t\t<!-- start: PANEL CONFIGURATION MODAL FORM -->
\t\t\t\t\t<div class=\"modal fade\" id=\"panel-config\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
\t\t\t\t\t\t<div class=\"modal-dialog\">
\t\t\t\t\t\t\t<div class=\"modal-content\">
\t\t\t\t\t\t\t\t<div class=\"modal-header\">
\t\t\t\t\t\t\t\t\t<button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">
\t\t\t\t\t\t\t\t\t\t&times;
\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t<h4 class=\"modal-title\">Panel Configuration</h4>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"modal-body\">
\t\t\t\t\t\t\t\t\tHere will be a configuration form
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"modal-footer\">
\t\t\t\t\t\t\t\t\t<button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">
\t\t\t\t\t\t\t\t\t\tClose
\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t<button type=\"button\" class=\"btn btn-primary\">
\t\t\t\t\t\t\t\t\t\tSave changes
\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<!-- /.modal-content -->
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<!-- /.modal-dialog -->
\t\t\t\t\t</div>
\t\t\t\t\t<!-- /.modal -->
\t\t\t\t\t<!-- end: SPANEL CONFIGURATION MODAL FORM -->
\t\t\t\t\t<div class=\"container\">
\t\t\t\t\t\t<!-- start: PAGE HEADER -->
\t\t\t\t\t\t<!-- start: TOOLBAR -->
\t\t\t\t\t\t<div class=\"toolbar row\">
\t\t\t\t\t\t\t<div class=\"col-sm-6 hidden-xs\">
\t\t\t\t\t\t\t\t<div class=\"page-header\">
\t\t\t\t\t\t\t\t\t<h1>Invoice <small>subtitle here</small></h1>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-sm-6 col-xs-12\">
\t\t\t\t\t\t\t\t<a href=\"#\" class=\"back-subviews\">
\t\t\t\t\t\t\t\t\t<i class=\"fa fa-chevron-left\"></i> BACK
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t<a href=\"#\" class=\"close-subviews\">
\t\t\t\t\t\t\t\t\t<i class=\"fa fa-times\"></i> CLOSE
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t<div class=\"toolbar-tools pull-right\">
\t\t\t\t\t\t\t\t\t<!-- start: TOP NAVIGATION MENU -->
\t\t\t\t\t\t\t\t\t<ul class=\"nav navbar-right\">
\t\t\t\t\t\t\t\t\t\t<!-- start: TO-DO DROPDOWN -->
\t\t\t\t\t\t\t\t\t\t<li class=\"dropdown\">
\t\t\t\t\t\t\t\t\t\t\t<a data-toggle=\"dropdown\" data-hover=\"dropdown\" class=\"dropdown-toggle\" data-close-others=\"true\" href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-plus\"></i> SUBVIEW
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"tooltip-notification hide\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"tooltip-notification-arrow\"></div>
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"tooltip-notification-inner\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"semi-bold\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tHI THERE!
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"message\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tTry the Subview Live Experience
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t<ul class=\"dropdown-menu dropdown-light dropdown-subview\">
\t\t\t\t\t\t\t\t\t\t\t\t<li class=\"dropdown-header\">
\t\t\t\t\t\t\t\t\t\t\t\t\tNotes
\t\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"#newNote\" class=\"new-note\"><span class=\"fa-stack\"> <i class=\"fa fa-file-text-o fa-stack-1x fa-lg\"></i> <i class=\"fa fa-plus fa-stack-1x stack-right-bottom text-danger\"></i> </span> Add new note</a>
\t\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"#readNote\" class=\"read-all-notes\"><span class=\"fa-stack\"> <i class=\"fa fa-file-text-o fa-stack-1x fa-lg\"></i> <i class=\"fa fa-share fa-stack-1x stack-right-bottom text-danger\"></i> </span> Read all notes</a>
\t\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t\t<li class=\"dropdown-header\">
\t\t\t\t\t\t\t\t\t\t\t\t\tCalendar
\t\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"#newEvent\" class=\"new-event\"><span class=\"fa-stack\"> <i class=\"fa fa-calendar-o fa-stack-1x fa-lg\"></i> <i class=\"fa fa-plus fa-stack-1x stack-right-bottom text-danger\"></i> </span> Add new event</a>
\t\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"#showCalendar\" class=\"show-calendar\"><span class=\"fa-stack\"> <i class=\"fa fa-calendar-o fa-stack-1x fa-lg\"></i> <i class=\"fa fa-share fa-stack-1x stack-right-bottom text-danger\"></i> </span> Show calendar</a>
\t\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t\t<li class=\"dropdown-header\">
\t\t\t\t\t\t\t\t\t\t\t\t\tContributors
\t\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"#newContributor\" class=\"new-contributor\"><span class=\"fa-stack\"> <i class=\"fa fa-user fa-stack-1x fa-lg\"></i> <i class=\"fa fa-plus fa-stack-1x stack-right-bottom text-danger\"></i> </span> Add new contributor</a>
\t\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"#showContributors\" class=\"show-contributors\"><span class=\"fa-stack\"> <i class=\"fa fa-user fa-stack-1x fa-lg\"></i> <i class=\"fa fa-share fa-stack-1x stack-right-bottom text-danger\"></i> </span> Show all contributor</a>
\t\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t<li class=\"dropdown\">
\t\t\t\t\t\t\t\t\t\t\t<a data-toggle=\"dropdown\" data-hover=\"dropdown\" class=\"dropdown-toggle\" data-close-others=\"true\" href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"messages-count badge badge-default hide\">3</span> <i class=\"fa fa-envelope\"></i> MESSAGES
\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t<ul class=\"dropdown-menu dropdown-light dropdown-messages\">
\t\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"dropdown-header\"> You have 9 messages</span>
\t\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"drop-down-wrapper ps-container\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<ul>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<li class=\"unread\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"javascript:;\" class=\"unread\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"clearfix\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"thread-image\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<img src=\"./assets/images/avatar-2.jpg\" alt=\"\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"thread-content\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"author\">Nicole Bell</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"preview\">Duis mollis, est non commodo luctus, nisi erat porttitor ligula...</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"time\"> Just Now</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"javascript:;\" class=\"unread\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"clearfix\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"thread-image\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<img src=\"./assets/images/avatar-3.jpg\" alt=\"\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"thread-content\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"author\">Steven Thompson</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"preview\">Duis mollis, est non commodo luctus, nisi erat porttitor ligula...</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"time\">8 hrs</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"javascript:;\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"clearfix\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"thread-image\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<img src=\"./assets/images/avatar-5.jpg\" alt=\"\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"thread-content\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"author\">Kenneth Ross</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"preview\">Duis mollis, est non commodo luctus, nisi erat porttitor ligula...</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"time\">14 hrs</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t\t<li class=\"view-all\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"pages_messages.html\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\tSee All
\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t<li class=\"menu-search\">
\t\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-search\"></i> SEARCH
\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t<!-- start: SEARCH POPOVER -->
\t\t\t\t\t\t\t\t\t\t\t<div class=\"popover bottom search-box transition-all\">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"arrow\"></div>
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"popover-content\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<!-- start: SEARCH FORM -->
\t\t\t\t\t\t\t\t\t\t\t\t\t<form class=\"\" id=\"searchform\" action=\"#\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"input-group\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"text\" class=\"form-control\" placeholder=\"Search\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"input-group-btn\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<button class=\"btn btn-main-color btn-squared\" type=\"button\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-search\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</button> </span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t</form>
\t\t\t\t\t\t\t\t\t\t\t\t\t<!-- end: SEARCH FORM -->
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<!-- end: SEARCH POPOVER -->
\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t\t\t<!-- end: TOP NAVIGATION MENU -->
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<!-- end: TOOLBAR -->
\t\t\t\t\t\t<!-- end: PAGE HEADER -->
\t\t\t\t\t\t<!-- start: BREADCRUMB -->
\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t\t<ol class=\"breadcrumb\">
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\tDashboard
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"active\">
\t\t\t\t\t\t\t\t\t\tInvoice
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t</ol>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<!-- end: BREADCRUMB -->
\t\t\t\t\t\t
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"subviews\">
\t\t\t\t\t\t<div class=\"subviews-container\"></div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<!-- end: PAGE -->
\t\t\t</div>
\t\t\t<!-- end: MAIN CONTAINER -->
\t\t\t<!-- start: FOOTER -->
\t\t\t<footer class=\"inner\">
\t\t\t\t<div class=\"footer-inner\">
\t\t\t\t\t<div class=\"pull-left\">
\t\t\t\t\t\t2014 &copy; Rapido by cliptheme.
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"pull-right\">
\t\t\t\t\t\t<span class=\"go-top\"><i class=\"fa fa-chevron-up\"></i></span>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</footer>
\t\t\t<!-- end: FOOTER -->
\t\t\t<!-- start: SUBVIEW SAMPLE CONTENTS -->
\t\t\t<!-- *** NEW NOTE *** -->
\t\t\t<div id=\"newNote\">
\t\t\t\t<div class=\"noteWrap col-md-8 col-md-offset-2\">
\t\t\t\t\t<h3>Add new note</h3>
\t\t\t\t\t<form class=\"form-note\">
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<input class=\"note-title form-control\" name=\"noteTitle\" type=\"text\" placeholder=\"Note Title...\">
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<textarea id=\"noteEditor\" name=\"noteEditor\" class=\"hide\"></textarea>
\t\t\t\t\t\t\t<textarea class=\"summernote\" placeholder=\"Write note here...\"></textarea>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"pull-right\">
\t\t\t\t\t\t\t<div class=\"btn-group\">
\t\t\t\t\t\t\t\t<a href=\"#\" class=\"btn btn-info close-subview-button\">
\t\t\t\t\t\t\t\t\tClose
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"btn-group\">
\t\t\t\t\t\t\t\t<button class=\"btn btn-info save-note\" type=\"submit\">
\t\t\t\t\t\t\t\t\tSave
\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</form>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<!-- *** READ NOTE *** -->
\t\t\t<div id=\"readNote\">
\t\t\t\t<div class=\"barTopSubview\">
\t\t\t\t\t<a href=\"#newNote\" class=\"new-note button-sv\"><i class=\"fa fa-plus\"></i> Add new note</a>
\t\t\t\t</div>
\t\t\t\t<div class=\"noteWrap col-md-8 col-md-offset-2\">
\t\t\t\t\t<div class=\"panel panel-note\">
\t\t\t\t\t\t<div class=\"e-slider owl-carousel owl-theme\">
\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t<div class=\"panel-heading\">
\t\t\t\t\t\t\t\t\t<h3>This is a Note</h3>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"panel-body\">
\t\t\t\t\t\t\t\t\t<div class=\"note-short-content\">
\t\t\t\t\t\t\t\t\t\tLorem ipsum dolor sit amet, consectetur adipisici elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Ut enim ad minim veniam...
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"note-content\">
\t\t\t\t\t\t\t\t\t\tLorem ipsum dolor sit amet, consectetur adipisici elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua.
\t\t\t\t\t\t\t\t\t\tUt enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquid ex ea commodi consequat.
\t\t\t\t\t\t\t\t\t\tQuis aute iure reprehenderit in <strong>voluptate velit</strong> esse cillum dolore eu fugiat nulla pariatur.
\t\t\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t\t\t\tExcepteur sint obcaecat cupiditat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
\t\t\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t\t\t\tNemo enim ipsam voluptatem, quia voluptas sit, aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos, qui ratione voluptatem sequi nesciunt, neque porro quisquam est, qui dolorem ipsum, quia dolor sit, amet, consectetur, adipisci v'elit, sed quia non numquam eius modi tempora incidunt, ut labore et dolore magnam aliquam quaerat voluptatem.
\t\t\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t\t\t\tUt enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut <strong>aliquid ex ea commodi consequatur?</strong>
\t\t\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t\t\t\tQuis autem vel eum iure reprehenderit, qui in ea voluptate velit esse, quam nihil molestiae consequatur, vel illum, qui dolorem eum fugiat, quo voluptas nulla pariatur?
\t\t\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t\t\t\tAt vero eos et accusamus et iusto odio dignissimos ducimus, qui blanditiis praesentium voluptatum deleniti atque corrupti, quos dolores et quas molestias excepturi sint, obcaecati cupiditate non provident, similique sunt in culpa, qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio.
\t\t\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t\t\t\tNam libero tempore, cum soluta nobis est eligendi optio, cumque nihil impedit, quo minus id, quod maxime placeat, facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet, ut et voluptates repudiandae sint et molestiae non recusandae.
\t\t\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t\t\t\tItaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"note-options pull-right\">
\t\t\t\t\t\t\t\t\t\t<a href=\"#readNote\" class=\"read-note\"><i class=\"fa fa-chevron-circle-right\"></i> Read</a><a href=\"#\" class=\"delete-note\"><i class=\"fa fa-times\"></i> Delete</a>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"panel-footer\">
\t\t\t\t\t\t\t\t\t<div class=\"avatar-note\"><img src=\"assets/images/avatar-2-small.jpg\" alt=\"\">
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<span class=\"author-note\">Nicole Bell</span>
\t\t\t\t\t\t\t\t\t<time class=\"timestamp\" title=\"2014-02-18T00:00:00-05:00\">
\t\t\t\t\t\t\t\t\t\t2014-02-18T00:00:00-05:00
\t\t\t\t\t\t\t\t\t</time>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t<div class=\"panel-heading\">
\t\t\t\t\t\t\t\t\t<h3>This is the second Note</h3>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"panel-body\">
\t\t\t\t\t\t\t\t\t<div class=\"note-short-content\">
\t\t\t\t\t\t\t\t\t\tExcepteur sint obcaecat cupiditat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nemo enim ipsam voluptatem, quia voluptas sit...
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"note-content\">
\t\t\t\t\t\t\t\t\t\tExcepteur sint obcaecat cupiditat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
\t\t\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t\t\t\tNemo enim ipsam voluptatem, quia voluptas sit, aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos, qui ratione voluptatem sequi nesciunt, neque porro quisquam est, qui dolorem ipsum, quia dolor sit, amet, consectetur, adipisci v'elit, sed quia non numquam eius modi tempora incidunt, ut labore et dolore magnam aliquam quaerat voluptatem.
\t\t\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t\t\t\tUt enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut <strong>aliquid ex ea commodi consequatur?</strong>
\t\t\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t\t\t\tQuis autem vel eum iure reprehenderit, qui in ea voluptate velit esse, quam nihil molestiae consequatur, vel illum, qui dolorem eum fugiat, quo voluptas nulla pariatur?
\t\t\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t\t\t\tNam libero tempore, cum soluta nobis est eligendi optio, cumque nihil impedit, quo minus id, quod maxime placeat, facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet, ut et voluptates repudiandae sint et molestiae non recusandae.
\t\t\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t\t\t\tItaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"note-options pull-right\">
\t\t\t\t\t\t\t\t\t\t<a href=\"#\" class=\"read-note\"><i class=\"fa fa-chevron-circle-right\"></i> Read</a><a href=\"#\" class=\"delete-note\"><i class=\"fa fa-times\"></i> Delete</a>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"panel-footer\">
\t\t\t\t\t\t\t\t\t<div class=\"avatar-note\"><img src=\"assets/images/avatar-3-small.jpg\" alt=\"\">
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<span class=\"author-note\">Steven Thompson</span>
\t\t\t\t\t\t\t\t\t<time class=\"timestamp\" title=\"2014-02-18T00:00:00-05:00\">
\t\t\t\t\t\t\t\t\t\t2014-02-18T00:00:00-05:00
\t\t\t\t\t\t\t\t\t</time>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t<div class=\"panel-heading\">
\t\t\t\t\t\t\t\t\t<h3>This is yet another Note</h3>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"panel-body\">
\t\t\t\t\t\t\t\t\t<div class=\"note-short-content\">
\t\t\t\t\t\t\t\t\t\tAt vero eos et accusamus et iusto odio dignissimos ducimus, qui blanditiis praesentium voluptatum deleniti atque corrupti, quos dolores...
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"note-content\">
\t\t\t\t\t\t\t\t\t\tAt vero eos et accusamus et iusto odio dignissimos ducimus, qui blanditiis praesentium voluptatum deleniti atque corrupti, quos dolores et quas molestias excepturi sint, obcaecati cupiditate non provident, similique sunt in culpa, qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio.
\t\t\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t\t\t\tExcepteur sint obcaecat cupiditat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
\t\t\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t\t\t\tNemo enim ipsam voluptatem, quia voluptas sit, aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos, qui ratione voluptatem sequi nesciunt, neque porro quisquam est, qui dolorem ipsum, quia dolor sit, amet, consectetur, adipisci v'elit, sed quia non numquam eius modi tempora incidunt, ut labore et dolore magnam aliquam quaerat voluptatem.
\t\t\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t\t\t\tUt enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut <strong>aliquid ex ea commodi consequatur?</strong>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"note-options pull-right\">
\t\t\t\t\t\t\t\t\t\t<a href=\"#\" class=\"read-note\"><i class=\"fa fa-chevron-circle-right\"></i> Read</a><a href=\"#\" class=\"delete-note\"><i class=\"fa fa-times\"></i> Delete</a>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"panel-footer\">
\t\t\t\t\t\t\t\t\t<div class=\"avatar-note\"><img src=\"assets/images/avatar-4-small.jpg\" alt=\"\">
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<span class=\"author-note\">Ella Patterson</span>
\t\t\t\t\t\t\t\t\t<time class=\"timestamp\" title=\"2014-02-18T00:00:00-05:00\">
\t\t\t\t\t\t\t\t\t\t2014-02-18T00:00:00-05:00
\t\t\t\t\t\t\t\t\t</time>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<!-- *** SHOW CALENDAR *** -->
\t\t\t<div id=\"showCalendar\" class=\"col-md-10 col-md-offset-1\">
\t\t\t\t<div class=\"barTopSubview\">
\t\t\t\t\t<a href=\"#newEvent\" class=\"new-event button-sv\" data-subviews-options='{\"onShow\": \"editEvent()\"}'><i class=\"fa fa-plus\"></i> Add new event</a>
\t\t\t\t</div>
\t\t\t\t<div id=\"calendar\"></div>
\t\t\t</div>
\t\t\t<!-- *** NEW EVENT *** -->
\t\t\t<div id=\"newEvent\">
\t\t\t\t<div class=\"noteWrap col-md-8 col-md-offset-2\">
\t\t\t\t\t<h3>Add new event</h3>
\t\t\t\t\t<form class=\"form-event\">
\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<input class=\"event-id hide\" type=\"text\">
\t\t\t\t\t\t\t\t\t<input class=\"event-name form-control\" name=\"eventName\" type=\"text\" placeholder=\"Event Name...\">
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-md-4\">
\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" class=\"all-day\" data-label-text=\"All-Day\" data-on-text=\"True\" data-off-text=\"False\">
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"no-all-day-range\">
\t\t\t\t\t\t\t\t<div class=\"col-md-8\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"input-icon\">
\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"text\" class=\"event-range-date form-control\" name=\"eventRangeDate\" placeholder=\"Range date\"/>
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-clock-o\"></i> </span>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"all-day-range\">
\t\t\t\t\t\t\t\t<div class=\"col-md-8\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"input-icon\">
\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"text\" class=\"event-range-date form-control\" name=\"ad_eventRangeDate\" placeholder=\"Range date\"/>
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-calendar\"></i> </span>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"hide\">
\t\t\t\t\t\t\t\t<input type=\"text\" class=\"event-start-date\" name=\"eventStartDate\"/>
\t\t\t\t\t\t\t\t<input type=\"text\" class=\"event-end-date\" name=\"eventEndDate\"/>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<select class=\"form-control selectpicker event-categories\">
\t\t\t\t\t\t\t\t\t\t<option data-content=\"<span class='event-category event-cancelled'>Cancelled</span>\" value=\"event-cancelled\">Cancelled</option>
\t\t\t\t\t\t\t\t\t\t<option data-content=\"<span class='event-category event-home'>Home</span>\" value=\"event-home\">Home</option>
\t\t\t\t\t\t\t\t\t\t<option data-content=\"<span class='event-category event-overtime'>Overtime</span>\" value=\"event-overtime\">Overtime</option>
\t\t\t\t\t\t\t\t\t\t<option data-content=\"<span class='event-category event-generic'>Generic</span>\" value=\"event-generic\" selected=\"selected\">Generic</option>
\t\t\t\t\t\t\t\t\t\t<option data-content=\"<span class='event-category event-job'>Job</span>\" value=\"event-job\">Job</option>
\t\t\t\t\t\t\t\t\t\t<option data-content=\"<span class='event-category event-offsite'>Off-site work</span>\" value=\"event-offsite\">Off-site work</option>
\t\t\t\t\t\t\t\t\t\t<option data-content=\"<span class='event-category event-todo'>To Do</span>\" value=\"event-todo\">To Do</option>
\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<textarea class=\"summernote\" placeholder=\"Write note here...\"></textarea>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"pull-right\">
\t\t\t\t\t\t\t<div class=\"btn-group\">
\t\t\t\t\t\t\t\t<a href=\"#\" class=\"btn btn-info close-subview-button\">
\t\t\t\t\t\t\t\t\tClose
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"btn-group\">
\t\t\t\t\t\t\t\t<button class=\"btn btn-info save-new-event\" type=\"submit\">
\t\t\t\t\t\t\t\t\tSave
\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</form>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<!-- *** READ EVENT *** -->
\t\t\t<div id=\"readEvent\">
\t\t\t\t<div class=\"noteWrap col-md-8 col-md-offset-2\">
\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t<h2 class=\"event-title\">Event Title</h2>
\t\t\t\t\t\t\t<div class=\"btn-group options-toggle pull-right\">
\t\t\t\t\t\t\t\t<button class=\"btn dropdown-toggle btn-transparent-grey\" data-toggle=\"dropdown\">
\t\t\t\t\t\t\t\t\t<i class=\"fa fa-cog\"></i>
\t\t\t\t\t\t\t\t\t<span class=\"caret\"></span>
\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t<ul role=\"menu\" class=\"dropdown-menu dropdown-light pull-right\">
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"#newEvent\" class=\"edit-event\">
\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-pencil\"></i> Edit
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"#\" class=\"delete-event\">
\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-times\"></i> Delete
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t<span class=\"event-category event-cancelled\">Cancelled</span>
\t\t\t\t\t\t\t<span class=\"event-allday\"><i class='fa fa-check'></i> All-Day</span>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t<div class=\"event-start\">
\t\t\t\t\t\t\t\t<div class=\"event-day\"></div>
\t\t\t\t\t\t\t\t<div class=\"event-date\"></div>
\t\t\t\t\t\t\t\t<div class=\"event-time\"></div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"event-end\"></div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t<div class=\"event-content\"></div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<!-- *** NEW CONTRIBUTOR *** -->
\t\t\t<div id=\"newContributor\">
\t\t\t\t<div class=\"noteWrap col-md-8 col-md-offset-2\">
\t\t\t\t\t<h3>Add new contributor</h3>
\t\t\t\t\t<form class=\"form-contributor\">
\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t\t<div class=\"errorHandler alert alert-danger no-display\">
\t\t\t\t\t\t\t\t\t<i class=\"fa fa-times-sign\"></i> You have some form errors. Please check below.
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"successHandler alert alert-success no-display\">
\t\t\t\t\t\t\t\t\t<i class=\"fa fa-ok\"></i> Your form validation is successful!
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<input class=\"contributor-id hide\" type=\"text\">
\t\t\t\t\t\t\t\t\t<label class=\"control-label\">
\t\t\t\t\t\t\t\t\t\tFirst Name <span class=\"symbol required\"></span>
\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t<input type=\"text\" placeholder=\"Insert your First Name\" class=\"form-control contributor-firstname\" name=\"firstname\">
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<label class=\"control-label\">
\t\t\t\t\t\t\t\t\t\tLast Name <span class=\"symbol required\"></span>
\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t<input type=\"text\" placeholder=\"Insert your Last Name\" class=\"form-control contributor-lastname\" name=\"lastname\">
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<label class=\"control-label\">
\t\t\t\t\t\t\t\t\t\tEmail Address <span class=\"symbol required\"></span>
\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t<input type=\"email\" placeholder=\"Text Field\" class=\"form-control contributor-email\" name=\"email\">
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<label class=\"control-label\">
\t\t\t\t\t\t\t\t\t\tPassword <span class=\"symbol required\"></span>
\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t<input type=\"password\" class=\"form-control contributor-password\" name=\"password\">
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<label class=\"control-label\">
\t\t\t\t\t\t\t\t\t\tConfirm Password <span class=\"symbol required\"></span>
\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t<input type=\"password\" class=\"form-control contributor-password-again\" name=\"password_again\">
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<label class=\"control-label\">
\t\t\t\t\t\t\t\t\t\tGender <span class=\"symbol required\"></span>
\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t\t\t<label class=\"radio-inline\">
\t\t\t\t\t\t\t\t\t\t\t<input type=\"radio\" class=\"grey contributor-gender\" value=\"F\" name=\"gender\">
\t\t\t\t\t\t\t\t\t\t\tFemale
\t\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t\t<label class=\"radio-inline\">
\t\t\t\t\t\t\t\t\t\t\t<input type=\"radio\" class=\"grey contributor-gender\" value=\"M\" name=\"gender\">
\t\t\t\t\t\t\t\t\t\t\tMale
\t\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<label class=\"control-label\">
\t\t\t\t\t\t\t\t\t\tPermits <span class=\"symbol required\"></span>
\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t<select name=\"permits\" class=\"form-control contributor-permits\" >
\t\t\t\t\t\t\t\t\t\t<option value=\"View and Edit\">View and Edit</option>
\t\t\t\t\t\t\t\t\t\t<option value=\"View Only\">View Only</option>
\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<div class=\"fileupload fileupload-new contributor-avatar\" data-provides=\"fileupload\">
\t\t\t\t\t\t\t\t\t\t<div class=\"fileupload-new thumbnail\"><img src=\"assets/images/anonymous.jpg\" alt=\"\" width=\"50\" height=\"50\"/>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"fileupload-preview fileupload-exists thumbnail\"></div>
\t\t\t\t\t\t\t\t\t\t<div class=\"contributor-avatar-options\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"btn btn-light-grey btn-file\"><span class=\"fileupload-new\"><i class=\"fa fa-picture-o\"></i> Select image</span><span class=\"fileupload-exists\"><i class=\"fa fa-picture-o\"></i> Change</span>
\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"file\">
\t\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t\t<a href=\"#\" class=\"btn fileupload-exists btn-light-grey\" data-dismiss=\"fileupload\">
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-times\"></i> Remove
\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<label class=\"control-label\">
\t\t\t\t\t\t\t\t\t\tSEND MESSAGE (Optional)
\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t<textarea class=\"form-control contributor-message\"></textarea>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"pull-right\">
\t\t\t\t\t\t\t<div class=\"btn-group\">
\t\t\t\t\t\t\t\t<a href=\"#\" class=\"btn btn-info close-subview-button\">
\t\t\t\t\t\t\t\t\tClose
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"btn-group\">
\t\t\t\t\t\t\t\t<button class=\"btn btn-info save-contributor\" type=\"submit\">
\t\t\t\t\t\t\t\t\tSave
\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</form>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<!-- *** SHOW CONTRIBUTORS *** -->
\t\t\t<div id=\"showContributors\">
\t\t\t\t<div class=\"barTopSubview\">
\t\t\t\t\t<a href=\"#newContributor\" class=\"new-contributor button-sv\"><i class=\"fa fa-plus\"></i> Add new contributor</a>
\t\t\t\t</div>
\t\t\t\t<div class=\"noteWrap col-md-10 col-md-offset-1\">
\t\t\t\t\t<div class=\"panel panel-default\">
\t\t\t\t\t\t<div class=\"panel-body\">
\t\t\t\t\t\t\t<div id=\"contributors\">
\t\t\t\t\t\t\t\t<div class=\"options-contributors hide\">
\t\t\t\t\t\t\t\t\t<div class=\"btn-group\">
\t\t\t\t\t\t\t\t\t\t<button class=\"btn dropdown-toggle btn-transparent-grey\" data-toggle=\"dropdown\">
\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-cog\"></i>
\t\t\t\t\t\t\t\t\t\t\t<span class=\"caret\"></span>
\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t<ul role=\"menu\" class=\"dropdown-menu dropdown-light pull-right\">
\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"#newContributor\" class=\"show-subviews edit-contributor\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-pencil\"></i> Edit
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"#\" class=\"delete-contributor\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-times\"></i> Delete
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<!-- end: SUBVIEW SAMPLE CONTENTS -->
\t\t</div>
\t\t<!-- start: MAIN JAVASCRIPTS -->
\t\t<!--[if lt IE 9]>
\t\t<script src=\"assets/plugins/respond.min.js\"></script>
\t\t<script src=\"assets/plugins/excanvas.min.js\"></script>
\t\t<script type=\"text/javascript\" src=\"assets/plugins/jQuery/jquery-1.11.1.min.js\"></script>
\t\t<![endif]-->
\t\t<!--[if gte IE 9]><!-->
\t\t<script src=\"assets/plugins/jQuery/jquery-2.1.1.min.js\"></script>
\t\t<!--<![endif]-->
\t\t<script src=\"assets/plugins/jquery-ui/jquery-ui-1.10.2.custom.min.js\"></script>
\t\t<script src=\"assets/plugins/bootstrap/js/bootstrap.min.js\"></script>
\t\t<script src=\"assets/plugins/blockUI/jquery.blockUI.js\"></script>
\t\t<script src=\"assets/plugins/iCheck/jquery.icheck.min.js\"></script>
\t\t<script src=\"assets/plugins/moment/min/moment.min.js\"></script>
\t\t<script src=\"assets/plugins/perfect-scrollbar/src/jquery.mousewheel.js\"></script>
\t\t<script src=\"assets/plugins/perfect-scrollbar/src/perfect-scrollbar.js\"></script>
\t\t<script src=\"assets/plugins/bootbox/bootbox.min.js\"></script>
\t\t<script src=\"assets/plugins/jquery.scrollTo/jquery.scrollTo.min.js\"></script>
\t\t<script src=\"assets/plugins/ScrollToFixed/jquery-scrolltofixed-min.js\"></script>
\t\t<script src=\"assets/plugins/jquery.appear/jquery.appear.js\"></script>
\t\t<script src=\"assets/plugins/jquery-cookie/jquery.cookie.js\"></script>
\t\t<script src=\"assets/plugins/velocity/jquery.velocity.min.js\"></script>
\t\t<script src=\"assets/plugins/TouchSwipe/jquery.touchSwipe.min.js\"></script>
\t\t<!-- end: MAIN JAVASCRIPTS -->
\t\t<!-- start: JAVASCRIPTS REQUIRED FOR SUBVIEW CONTENTS -->
\t\t<script src=\"assets/plugins/owl-carousel/owl-carousel/owl.carousel.js\"></script>
\t\t<script src=\"assets/plugins/jquery-mockjax/jquery.mockjax.js\"></script>
\t\t<script src=\"assets/plugins/toastr/toastr.js\"></script>
\t\t<script src=\"assets/plugins/bootstrap-modal/js/bootstrap-modal.js\"></script>
\t\t<script src=\"assets/plugins/bootstrap-modal/js/bootstrap-modalmanager.js\"></script>
\t\t<script src=\"assets/plugins/fullcalendar/fullcalendar/fullcalendar.min.js\"></script>
\t\t<script src=\"assets/plugins/bootstrap-switch/dist/js/bootstrap-switch.min.js\"></script>
\t\t<script src=\"assets/plugins/bootstrap-select/bootstrap-select.min.js\"></script>
\t\t<script src=\"assets/plugins/jquery-validation/dist/jquery.validate.min.js\"></script>
\t\t<script src=\"assets/plugins/bootstrap-fileupload/bootstrap-fileupload.min.js\"></script>
\t\t<script src=\"assets/plugins/DataTables/media/js/jquery.dataTables.min.js\"></script>
\t\t
\t\t<script src=\"assets/plugins/truncate/jquery.truncate.js\"></script>
\t\t<script src=\"assets/plugins/summernote/dist/summernote.min.js\"></script>
\t\t<script src=\"assets/plugins/bootstrap-daterangepicker/daterangepicker.js\"></script>
\t\t<script src=\"assets/js/subview.js\"></script>
\t\t<script src=\"assets/js/subview-examples.js\"></script>
\t\t<!-- end: JAVASCRIPTS REQUIRED FOR SUBVIEW CONTENTS -->
\t\t<!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
\t\t<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
\t\t<!-- start: CORE JAVASCRIPTS  -->
\t\t<script src=\"assets/js/main.js\"></script>
\t\t<!-- end: CORE JAVASCRIPTS  -->
\t\t<script>
\t\t\tjQuery(document).ready(function() {
\t\t\t\tMain.init();
\t\t\t\tSVExamples.init();
\t\t\t});
\t\t</script>
\t</body>
\t<!-- end: BODY -->
</html>";
    }

    public function getTemplateName()
    {
        return "welcome_message.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  33 => 13,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "welcome_message.twig", "C:\\xampp\\htdocs\\LeadMlm\\application\\views\\welcome_message.twig");
    }
}
