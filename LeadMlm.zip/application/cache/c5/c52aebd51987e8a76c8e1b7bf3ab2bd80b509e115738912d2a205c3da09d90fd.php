<?php

/* admin/home/index.twig */
class __TwigTemplate_91ba382bd955edc69650b3f62b782e54fdb40036d86e36a1122b704dd71d30ca extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $this->loadTemplate("admin/layout/header.twig", "admin/home/index.twig", 1)->display($context);
        // line 2
        $this->loadTemplate("admin/layout/top_bar.twig", "admin/home/index.twig", 2)->display($context);
        // line 3
        $this->loadTemplate("admin/layout/main_container.twig", "admin/home/index.twig", 3)->display($context);
        // line 4
        $this->loadTemplate("admin/layout/menu.twig", "admin/home/index.twig", 4)->display($context);
        // line 5
        echo "
";
        // line 6
        $this->loadTemplate("admin/layout/page_right.twig", "admin/home/index.twig", 6)->display($context);
        // line 7
        echo "


";
        // line 10
        $this->loadTemplate("admin/layout/footer.twig", "admin/home/index.twig", 10)->display($context);
    }

    public function getTemplateName()
    {
        return "admin/home/index.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  37 => 10,  32 => 7,  30 => 6,  27 => 5,  25 => 4,  23 => 3,  21 => 2,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "admin/home/index.twig", "C:\\xampp\\htdocs\\LeadMlm\\application\\views\\admin\\home\\index.twig");
    }
}
