<?php

/* admin/layout/footer.twig */
class __TwigTemplate_eb9eabd200de570f2dee53c01afb856dc647f78524649985f257fe1a765c2fd6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "
\t\t\t\t\t\t
\t\t\t\t\t\t<!-- end:  MAIN CONTENT -->
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"subviews\">
\t\t\t\t\t\t<div class=\"subviews-container\"></div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<!-- end: PAGE -->
\t\t\t</div>
\t\t\t<!-- end: MAIN CONTAINER -->
\t\t\t<!-- start: FOOTER -->
\t\t\t<footer class=\"inner\">
\t\t\t\t<div class=\"footer-inner\">
\t\t\t\t\t<div class=\"pull-left\">
\t\t\t\t\t\t2014 &copy; Rapido by cliptheme.
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"pull-right\">
\t\t\t\t\t\t<span class=\"go-top\"><i class=\"fa fa-chevron-up\"></i></span>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</footer>
\t\t\t<!-- end: FOOTER -->
\t\t\t<!-- start: SUBVIEW SAMPLE CONTENTS -->
\t\t\t<!-- *** NEW NOTE *** -->
\t\t\t<div id=\"newNote\">
\t\t\t\t<div class=\"noteWrap col-md-8 col-md-offset-2\">
\t\t\t\t\t<h3>Add new note</h3>
\t\t\t\t\t<form class=\"form-note\">
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<input class=\"note-title form-control\" name=\"noteTitle\" type=\"text\" placeholder=\"Note Title...\">
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t<textarea id=\"noteEditor\" name=\"noteEditor\" class=\"hide\"></textarea>
\t\t\t\t\t\t\t<textarea class=\"summernote\" placeholder=\"Write note here...\"></textarea>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"pull-right\">
\t\t\t\t\t\t\t<div class=\"btn-group\">
\t\t\t\t\t\t\t\t<a href=\"#\" class=\"btn btn-info close-subview-button\">
\t\t\t\t\t\t\t\t\tClose
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"btn-group\">
\t\t\t\t\t\t\t\t<button class=\"btn btn-info save-note\" type=\"submit\">
\t\t\t\t\t\t\t\t\tSave
\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</form>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<!-- *** READ NOTE *** -->
\t\t\t<div id=\"readNote\">
\t\t\t\t<div class=\"barTopSubview\">
\t\t\t\t\t<a href=\"#newNote\" class=\"new-note button-sv\"><i class=\"fa fa-plus\"></i> Add new note</a>
\t\t\t\t</div>
\t\t\t\t<div class=\"noteWrap col-md-8 col-md-offset-2\">
\t\t\t\t\t<div class=\"panel panel-note\">
\t\t\t\t\t\t<div class=\"e-slider owl-carousel owl-theme\">
\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t<div class=\"panel-heading\">
\t\t\t\t\t\t\t\t\t<h3>This is a Note</h3>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"panel-body\">
\t\t\t\t\t\t\t\t\t<div class=\"note-short-content\">
\t\t\t\t\t\t\t\t\t\tLorem ipsum dolor sit amet, consectetur adipisici elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Ut enim ad minim veniam...
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"note-content\">
\t\t\t\t\t\t\t\t\t\tLorem ipsum dolor sit amet, consectetur adipisici elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua.
\t\t\t\t\t\t\t\t\t\tUt enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquid ex ea commodi consequat.
\t\t\t\t\t\t\t\t\t\tQuis aute iure reprehenderit in <strong>voluptate velit</strong> esse cillum dolore eu fugiat nulla pariatur.
\t\t\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t\t\t\tExcepteur sint obcaecat cupiditat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
\t\t\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t\t\t\tNemo enim ipsam voluptatem, quia voluptas sit, aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos, qui ratione voluptatem sequi nesciunt, neque porro quisquam est, qui dolorem ipsum, quia dolor sit, amet, consectetur, adipisci v'elit, sed quia non numquam eius modi tempora incidunt, ut labore et dolore magnam aliquam quaerat voluptatem.
\t\t\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t\t\t\tUt enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut <strong>aliquid ex ea commodi consequatur?</strong>
\t\t\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t\t\t\tQuis autem vel eum iure reprehenderit, qui in ea voluptate velit esse, quam nihil molestiae consequatur, vel illum, qui dolorem eum fugiat, quo voluptas nulla pariatur?
\t\t\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t\t\t\tAt vero eos et accusamus et iusto odio dignissimos ducimus, qui blanditiis praesentium voluptatum deleniti atque corrupti, quos dolores et quas molestias excepturi sint, obcaecati cupiditate non provident, similique sunt in culpa, qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio.
\t\t\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t\t\t\tNam libero tempore, cum soluta nobis est eligendi optio, cumque nihil impedit, quo minus id, quod maxime placeat, facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet, ut et voluptates repudiandae sint et molestiae non recusandae.
\t\t\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t\t\t\tItaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"note-options pull-right\">
\t\t\t\t\t\t\t\t\t\t<a href=\"#readNote\" class=\"read-note\"><i class=\"fa fa-chevron-circle-right\"></i> Read</a><a href=\"#\" class=\"delete-note\"><i class=\"fa fa-times\"></i> Delete</a>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"panel-footer\">
\t\t\t\t\t\t\t\t\t<div class=\"avatar-note\"><img src=\"assets/images/avatar-2-small.jpg\" alt=\"\">
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<span class=\"author-note\">Nicole Bell</span>
\t\t\t\t\t\t\t\t\t<time class=\"timestamp\" title=\"2014-02-18T00:00:00-05:00\">
\t\t\t\t\t\t\t\t\t\t2014-02-18T00:00:00-05:00
\t\t\t\t\t\t\t\t\t</time>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t<div class=\"panel-heading\">
\t\t\t\t\t\t\t\t\t<h3>This is the second Note</h3>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"panel-body\">
\t\t\t\t\t\t\t\t\t<div class=\"note-short-content\">
\t\t\t\t\t\t\t\t\t\tExcepteur sint obcaecat cupiditat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nemo enim ipsam voluptatem, quia voluptas sit...
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"note-content\">
\t\t\t\t\t\t\t\t\t\tExcepteur sint obcaecat cupiditat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
\t\t\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t\t\t\tNemo enim ipsam voluptatem, quia voluptas sit, aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos, qui ratione voluptatem sequi nesciunt, neque porro quisquam est, qui dolorem ipsum, quia dolor sit, amet, consectetur, adipisci v'elit, sed quia non numquam eius modi tempora incidunt, ut labore et dolore magnam aliquam quaerat voluptatem.
\t\t\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t\t\t\tUt enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut <strong>aliquid ex ea commodi consequatur?</strong>
\t\t\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t\t\t\tQuis autem vel eum iure reprehenderit, qui in ea voluptate velit esse, quam nihil molestiae consequatur, vel illum, qui dolorem eum fugiat, quo voluptas nulla pariatur?
\t\t\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t\t\t\tNam libero tempore, cum soluta nobis est eligendi optio, cumque nihil impedit, quo minus id, quod maxime placeat, facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet, ut et voluptates repudiandae sint et molestiae non recusandae.
\t\t\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t\t\t\tItaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"note-options pull-right\">
\t\t\t\t\t\t\t\t\t\t<a href=\"#\" class=\"read-note\"><i class=\"fa fa-chevron-circle-right\"></i> Read</a><a href=\"#\" class=\"delete-note\"><i class=\"fa fa-times\"></i> Delete</a>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"panel-footer\">
\t\t\t\t\t\t\t\t\t<div class=\"avatar-note\"><img src=\"assets/images/avatar-3-small.jpg\" alt=\"\">
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<span class=\"author-note\">Steven Thompson</span>
\t\t\t\t\t\t\t\t\t<time class=\"timestamp\" title=\"2014-02-18T00:00:00-05:00\">
\t\t\t\t\t\t\t\t\t\t2014-02-18T00:00:00-05:00
\t\t\t\t\t\t\t\t\t</time>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t<div class=\"panel-heading\">
\t\t\t\t\t\t\t\t\t<h3>This is yet another Note</h3>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"panel-body\">
\t\t\t\t\t\t\t\t\t<div class=\"note-short-content\">
\t\t\t\t\t\t\t\t\t\tAt vero eos et accusamus et iusto odio dignissimos ducimus, qui blanditiis praesentium voluptatum deleniti atque corrupti, quos dolores...
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"note-content\">
\t\t\t\t\t\t\t\t\t\tAt vero eos et accusamus et iusto odio dignissimos ducimus, qui blanditiis praesentium voluptatum deleniti atque corrupti, quos dolores et quas molestias excepturi sint, obcaecati cupiditate non provident, similique sunt in culpa, qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio.
\t\t\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t\t\t\tExcepteur sint obcaecat cupiditat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
\t\t\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t\t\t\tNemo enim ipsam voluptatem, quia voluptas sit, aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos, qui ratione voluptatem sequi nesciunt, neque porro quisquam est, qui dolorem ipsum, quia dolor sit, amet, consectetur, adipisci v'elit, sed quia non numquam eius modi tempora incidunt, ut labore et dolore magnam aliquam quaerat voluptatem.
\t\t\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t\t\t\tUt enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut <strong>aliquid ex ea commodi consequatur?</strong>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"note-options pull-right\">
\t\t\t\t\t\t\t\t\t\t<a href=\"#\" class=\"read-note\"><i class=\"fa fa-chevron-circle-right\"></i> Read</a><a href=\"#\" class=\"delete-note\"><i class=\"fa fa-times\"></i> Delete</a>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"panel-footer\">
\t\t\t\t\t\t\t\t\t<div class=\"avatar-note\"><img src=\"assets/images/avatar-4-small.jpg\" alt=\"\">
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<span class=\"author-note\">Ella Patterson</span>
\t\t\t\t\t\t\t\t\t<time class=\"timestamp\" title=\"2014-02-18T00:00:00-05:00\">
\t\t\t\t\t\t\t\t\t\t2014-02-18T00:00:00-05:00
\t\t\t\t\t\t\t\t\t</time>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<!-- *** SHOW CALENDAR *** -->
\t\t\t<div id=\"showCalendar\" class=\"col-md-10 col-md-offset-1\">
\t\t\t\t<div class=\"barTopSubview\">
\t\t\t\t\t<a href=\"#newEvent\" class=\"new-event button-sv\" data-subviews-options='{\"onShow\": \"editEvent()\"}'><i class=\"fa fa-plus\"></i> Add new event</a>
\t\t\t\t</div>
\t\t\t\t<div id=\"calendar\"></div>
\t\t\t</div>
\t\t\t<!-- *** NEW EVENT *** -->
\t\t\t<div id=\"newEvent\">
\t\t\t\t<div class=\"noteWrap col-md-8 col-md-offset-2\">
\t\t\t\t\t<h3>Add new event</h3>
\t\t\t\t\t<form class=\"form-event\">
\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<input class=\"event-id hide\" type=\"text\">
\t\t\t\t\t\t\t\t\t<input class=\"event-name form-control\" name=\"eventName\" type=\"text\" placeholder=\"Event Name...\">
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-md-4\">
\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" class=\"all-day\" data-label-text=\"All-Day\" data-on-text=\"True\" data-off-text=\"False\">
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"no-all-day-range\">
\t\t\t\t\t\t\t\t<div class=\"col-md-8\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"input-icon\">
\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"text\" class=\"event-range-date form-control\" name=\"eventRangeDate\" placeholder=\"Range date\"/>
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-clock-o\"></i> </span>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"all-day-range\">
\t\t\t\t\t\t\t\t<div class=\"col-md-8\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"input-icon\">
\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"text\" class=\"event-range-date form-control\" name=\"ad_eventRangeDate\" placeholder=\"Range date\"/>
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-calendar\"></i> </span>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"hide\">
\t\t\t\t\t\t\t\t<input type=\"text\" class=\"event-start-date\" name=\"eventStartDate\"/>
\t\t\t\t\t\t\t\t<input type=\"text\" class=\"event-end-date\" name=\"eventEndDate\"/>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<select class=\"form-control selectpicker event-categories\">
\t\t\t\t\t\t\t\t\t\t<option data-content=\"<span class='event-category event-cancelled'>Cancelled</span>\" value=\"event-cancelled\">Cancelled</option>
\t\t\t\t\t\t\t\t\t\t<option data-content=\"<span class='event-category event-home'>Home</span>\" value=\"event-home\">Home</option>
\t\t\t\t\t\t\t\t\t\t<option data-content=\"<span class='event-category event-overtime'>Overtime</span>\" value=\"event-overtime\">Overtime</option>
\t\t\t\t\t\t\t\t\t\t<option data-content=\"<span class='event-category event-generic'>Generic</span>\" value=\"event-generic\" selected=\"selected\">Generic</option>
\t\t\t\t\t\t\t\t\t\t<option data-content=\"<span class='event-category event-job'>Job</span>\" value=\"event-job\">Job</option>
\t\t\t\t\t\t\t\t\t\t<option data-content=\"<span class='event-category event-offsite'>Off-site work</span>\" value=\"event-offsite\">Off-site work</option>
\t\t\t\t\t\t\t\t\t\t<option data-content=\"<span class='event-category event-todo'>To Do</span>\" value=\"event-todo\">To Do</option>
\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<textarea class=\"summernote\" placeholder=\"Write note here...\"></textarea>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"pull-right\">
\t\t\t\t\t\t\t<div class=\"btn-group\">
\t\t\t\t\t\t\t\t<a href=\"#\" class=\"btn btn-info close-subview-button\">
\t\t\t\t\t\t\t\t\tClose
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"btn-group\">
\t\t\t\t\t\t\t\t<button class=\"btn btn-info save-new-event\" type=\"submit\">
\t\t\t\t\t\t\t\t\tSave
\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</form>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<!-- *** READ EVENT *** -->
\t\t\t<div id=\"readEvent\">
\t\t\t\t<div class=\"noteWrap col-md-8 col-md-offset-2\">
\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t<h2 class=\"event-title\">Event Title</h2>
\t\t\t\t\t\t\t<div class=\"btn-group options-toggle pull-right\">
\t\t\t\t\t\t\t\t<button class=\"btn dropdown-toggle btn-transparent-grey\" data-toggle=\"dropdown\">
\t\t\t\t\t\t\t\t\t<i class=\"fa fa-cog\"></i>
\t\t\t\t\t\t\t\t\t<span class=\"caret\"></span>
\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t<ul role=\"menu\" class=\"dropdown-menu dropdown-light pull-right\">
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"#newEvent\" class=\"edit-event\">
\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-pencil\"></i> Edit
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<a href=\"#\" class=\"delete-event\">
\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-times\"></i> Delete
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t<span class=\"event-category event-cancelled\">Cancelled</span>
\t\t\t\t\t\t\t<span class=\"event-allday\"><i class='fa fa-check'></i> All-Day</span>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t<div class=\"event-start\">
\t\t\t\t\t\t\t\t<div class=\"event-day\"></div>
\t\t\t\t\t\t\t\t<div class=\"event-date\"></div>
\t\t\t\t\t\t\t\t<div class=\"event-time\"></div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"event-end\"></div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t<div class=\"event-content\"></div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<!-- *** NEW CONTRIBUTOR *** -->
\t\t\t<div id=\"newContributor\">
\t\t\t\t<div class=\"noteWrap col-md-8 col-md-offset-2\">
\t\t\t\t\t<h3>Add new contributor</h3>
\t\t\t\t\t<form class=\"form-contributor\">
\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t\t<div class=\"errorHandler alert alert-danger no-display\">
\t\t\t\t\t\t\t\t\t<i class=\"fa fa-times-sign\"></i> You have some form errors. Please check below.
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"successHandler alert alert-success no-display\">
\t\t\t\t\t\t\t\t\t<i class=\"fa fa-ok\"></i> Your form validation is successful!
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<input class=\"contributor-id hide\" type=\"text\">
\t\t\t\t\t\t\t\t\t<label class=\"control-label\">
\t\t\t\t\t\t\t\t\t\tFirst Name <span class=\"symbol required\"></span>
\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t<input type=\"text\" placeholder=\"Insert your First Name\" class=\"form-control contributor-firstname\" name=\"firstname\">
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<label class=\"control-label\">
\t\t\t\t\t\t\t\t\t\tLast Name <span class=\"symbol required\"></span>
\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t<input type=\"text\" placeholder=\"Insert your Last Name\" class=\"form-control contributor-lastname\" name=\"lastname\">
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<label class=\"control-label\">
\t\t\t\t\t\t\t\t\t\tEmail Address <span class=\"symbol required\"></span>
\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t<input type=\"email\" placeholder=\"Text Field\" class=\"form-control contributor-email\" name=\"email\">
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<label class=\"control-label\">
\t\t\t\t\t\t\t\t\t\tPassword <span class=\"symbol required\"></span>
\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t<input type=\"password\" class=\"form-control contributor-password\" name=\"password\">
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<label class=\"control-label\">
\t\t\t\t\t\t\t\t\t\tConfirm Password <span class=\"symbol required\"></span>
\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t<input type=\"password\" class=\"form-control contributor-password-again\" name=\"password_again\">
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<label class=\"control-label\">
\t\t\t\t\t\t\t\t\t\tGender <span class=\"symbol required\"></span>
\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t\t\t<label class=\"radio-inline\">
\t\t\t\t\t\t\t\t\t\t\t<input type=\"radio\" class=\"grey contributor-gender\" value=\"F\" name=\"gender\">
\t\t\t\t\t\t\t\t\t\t\tFemale
\t\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t\t<label class=\"radio-inline\">
\t\t\t\t\t\t\t\t\t\t\t<input type=\"radio\" class=\"grey contributor-gender\" value=\"M\" name=\"gender\">
\t\t\t\t\t\t\t\t\t\t\tMale
\t\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<label class=\"control-label\">
\t\t\t\t\t\t\t\t\t\tPermits <span class=\"symbol required\"></span>
\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t<select name=\"permits\" class=\"form-control contributor-permits\" >
\t\t\t\t\t\t\t\t\t\t<option value=\"View and Edit\">View and Edit</option>
\t\t\t\t\t\t\t\t\t\t<option value=\"View Only\">View Only</option>
\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<div class=\"fileupload fileupload-new contributor-avatar\" data-provides=\"fileupload\">
\t\t\t\t\t\t\t\t\t\t<div class=\"fileupload-new thumbnail\"><img src=\"assets/images/anonymous.jpg\" alt=\"\" width=\"50\" height=\"50\"/>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"fileupload-preview fileupload-exists thumbnail\"></div>
\t\t\t\t\t\t\t\t\t\t<div class=\"contributor-avatar-options\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"btn btn-light-grey btn-file\"><span class=\"fileupload-new\"><i class=\"fa fa-picture-o\"></i> Select image</span><span class=\"fileupload-exists\"><i class=\"fa fa-picture-o\"></i> Change</span>
\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"file\">
\t\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t\t<a href=\"#\" class=\"btn fileupload-exists btn-light-grey\" data-dismiss=\"fileupload\">
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-times\"></i> Remove
\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<label class=\"control-label\">
\t\t\t\t\t\t\t\t\t\tSEND MESSAGE (Optional)
\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t<textarea class=\"form-control contributor-message\"></textarea>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"pull-right\">
\t\t\t\t\t\t\t<div class=\"btn-group\">
\t\t\t\t\t\t\t\t<a href=\"#\" class=\"btn btn-info close-subview-button\">
\t\t\t\t\t\t\t\t\tClose
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"btn-group\">
\t\t\t\t\t\t\t\t<button class=\"btn btn-info save-contributor\" type=\"submit\">
\t\t\t\t\t\t\t\t\tSave
\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</form>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<!-- *** SHOW CONTRIBUTORS *** -->
\t\t\t<div id=\"showContributors\">
\t\t\t\t<div class=\"barTopSubview\">
\t\t\t\t\t<a href=\"#newContributor\" class=\"new-contributor button-sv\"><i class=\"fa fa-plus\"></i> Add new contributor</a>
\t\t\t\t</div>
\t\t\t\t<div class=\"noteWrap col-md-10 col-md-offset-1\">
\t\t\t\t\t<div class=\"panel panel-default\">
\t\t\t\t\t\t<div class=\"panel-body\">
\t\t\t\t\t\t\t<div id=\"contributors\">
\t\t\t\t\t\t\t\t<div class=\"options-contributors hide\">
\t\t\t\t\t\t\t\t\t<div class=\"btn-group\">
\t\t\t\t\t\t\t\t\t\t<button class=\"btn dropdown-toggle btn-transparent-grey\" data-toggle=\"dropdown\">
\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-cog\"></i>
\t\t\t\t\t\t\t\t\t\t\t<span class=\"caret\"></span>
\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t<ul role=\"menu\" class=\"dropdown-menu dropdown-light pull-right\">
\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"#newContributor\" class=\"show-subviews edit-contributor\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-pencil\"></i> Edit
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"#\" class=\"delete-contributor\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-times\"></i> Delete
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<!-- end: SUBVIEW SAMPLE CONTENTS -->
\t\t</div>
\t\t<!-- start: MAIN JAVASCRIPTS -->
\t\t<!--[if lt IE 9]>
\t\t<script src=\"assets/plugins/respond.min.js\"></script>
\t\t<script src=\"assets/plugins/excanvas.min.js\"></script>
\t\t<script type=\"text/javascript\" src=\"assets/plugins/jQuery/jquery-1.11.1.min.js\"></script>
\t\t<![endif]-->
\t\t<!--[if gte IE 9]><!-->
\t\t<script src=\"assets/plugins/jQuery/jquery-2.1.1.min.js\"></script>
\t\t<!--<![endif]-->
\t\t<script src=\"assets/plugins/jquery-ui/jquery-ui-1.10.2.custom.min.js\"></script>
\t\t<script src=\"assets/plugins/bootstrap/js/bootstrap.min.js\"></script>
\t\t<script src=\"assets/plugins/blockUI/jquery.blockUI.js\"></script>
\t\t<script src=\"assets/plugins/iCheck/jquery.icheck.min.js\"></script>
\t\t<script src=\"assets/plugins/moment/min/moment.min.js\"></script>
\t\t<script src=\"assets/plugins/perfect-scrollbar/src/jquery.mousewheel.js\"></script>
\t\t<script src=\"assets/plugins/perfect-scrollbar/src/perfect-scrollbar.js\"></script>
\t\t<script src=\"assets/plugins/bootbox/bootbox.min.js\"></script>
\t\t<script src=\"assets/plugins/jquery.scrollTo/jquery.scrollTo.min.js\"></script>
\t\t<script src=\"assets/plugins/ScrollToFixed/jquery-scrolltofixed-min.js\"></script>
\t\t<script src=\"assets/plugins/jquery.appear/jquery.appear.js\"></script>
\t\t<script src=\"assets/plugins/jquery-cookie/jquery.cookie.js\"></script>
\t\t<script src=\"assets/plugins/velocity/jquery.velocity.min.js\"></script>
\t\t<script src=\"assets/plugins/TouchSwipe/jquery.touchSwipe.min.js\"></script>
\t\t<!-- end: MAIN JAVASCRIPTS -->
\t\t<!-- start: JAVASCRIPTS REQUIRED FOR SUBVIEW CONTENTS -->
\t\t<script src=\"assets/plugins/owl-carousel/owl-carousel/owl.carousel.js\"></script>
\t\t<script src=\"assets/plugins/jquery-mockjax/jquery.mockjax.js\"></script>
\t\t<script src=\"assets/plugins/toastr/toastr.js\"></script>
\t\t<script src=\"assets/plugins/bootstrap-modal/js/bootstrap-modal.js\"></script>
\t\t<script src=\"assets/plugins/bootstrap-modal/js/bootstrap-modalmanager.js\"></script>
\t\t<script src=\"assets/plugins/fullcalendar/fullcalendar/fullcalendar.min.js\"></script>
\t\t<script src=\"assets/plugins/bootstrap-switch/dist/js/bootstrap-switch.min.js\"></script>
\t\t<script src=\"assets/plugins/bootstrap-select/bootstrap-select.min.js\"></script>
\t\t<script src=\"assets/plugins/jquery-validation/dist/jquery.validate.min.js\"></script>
\t\t<script src=\"assets/plugins/bootstrap-fileupload/bootstrap-fileupload.min.js\"></script>
\t\t<script src=\"assets/plugins/DataTables/media/js/jquery.dataTables.min.js\"></script>
\t\t
\t\t<script src=\"assets/plugins/truncate/jquery.truncate.js\"></script>
\t\t<script src=\"assets/plugins/summernote/dist/summernote.min.js\"></script>
\t\t<script src=\"assets/plugins/bootstrap-daterangepicker/daterangepicker.js\"></script>
\t\t<script src=\"assets/js/subview.js\"></script>
\t\t<script src=\"assets/js/subview-examples.js\"></script>
\t\t<!-- end: JAVASCRIPTS REQUIRED FOR SUBVIEW CONTENTS -->
\t\t<!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
\t\t<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
\t\t<!-- start: CORE JAVASCRIPTS  -->
\t\t<script src=\"assets/js/main.js\"></script>
\t\t<!-- end: CORE JAVASCRIPTS  -->
\t\t<script>
\t\t\tjQuery(document).ready(function() {
\t\t\t\tMain.init();
\t\t\t\tSVExamples.init();
\t\t\t});
\t\t</script>
\t</body>
\t<!-- end: BODY -->
</html>";
    }

    public function getTemplateName()
    {
        return "admin/layout/footer.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "admin/layout/footer.twig", "C:\\xampp\\htdocs\\LeadMlm\\application\\views\\admin\\layout\\footer.twig");
    }
}
